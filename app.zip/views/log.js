import { StyleSheet, Text, View, SafeAreaView, TouchableOpacity, ScrollView, TextInput } from 'react-native'
import { Ionicons, AntDesign, Entypo, MaterialCommunityIcons } from '@expo/vector-icons'
import { useState } from "react"
import { LinearGradient } from 'expo-linear-gradient'
import { Collapse, CollapseHeader, CollapseBody } from "accordion-collapse-react-native"
import AsyncStorage from "@react-native-async-storage/async-storage"
import SelectDropdown from 'react-native-select-dropdown'
import Checkbox from "expo-checkbox"

const currYear = new Date().getFullYear()
const numCurrMonth = new Date().getMonth() + 1

export default function Log({navigation}) {

    // AsyncStorage.getItem("firstWeight").then((firstWeight) => {
    //     setFirstWeight(firstWeight)
    // }).catch((error) => {
    //     console.log(error)
    // })

    // AsyncStorage.getItem("firstRep").then((firstRep) => {
    //     setFirstRep(firstRep)
    // }).catch((error) => {
    //     console.log(error)
    // })

    // AsyncStorage.getItem("secondWeight").then((secondWeight) => {
    //     setSecondWeight(secondWeight)
    // }).catch((error) => {
    //     console.log(error)
    // })

    // AsyncStorage.getItem("secondRep").then((secondRep) => {
    //     setSecondRep(secondRep)
    // }).catch((error) => {
    //     console.log(error)
    // })

    // AsyncStorage.getItem("thirdWeight").then((thirdWeight) => {
    //     setThirdWeight(thirdWeight)
    // }).catch((error) => {
    //     console.log(error)
    // })

    // AsyncStorage.getItem("thirdRep").then((thirdRep) => {
    //     setThirdRep(thirdRep)
    // }).catch((error) => {
    //     console.log(error)
    // })

    // AsyncStorage.getItem("fourthWeight").then((fourthWeight) => {
    //     setFourthWeight(fourthWeight)
    // }).catch((error) => {
    //     console.log(error)
    // })

    // AsyncStorage.getItem("fourthRep").then((fourthRep) => {
    //     setFourthRep(fourthRep)
    // }).catch((error) => {
    //     console.log(error)
    // })

    // AsyncStorage.getItem("fifthWeight").then((fifthWeight) => {
    //     setFifthWeight(fifthWeight)
    // }).catch((error) => {
    //     console.log(error)
    // })

    // AsyncStorage.getItem("fifthRep").then((fifthRep) => {
    //     setFifthRep(fifthRep)
    // }).catch((error) => {
    //     console.log(error)
    // })

    const Back = (props) => (
        <TouchableOpacity style = {props.arrow} onPress = {props.action}>
            <Ionicons name = "ios-arrow-back" size = {30} color = "white"/>
        </TouchableOpacity>
    )

    const Stage = (props) => (
        <View style = {props.header}>
            <Text style = {props.titleFont}>{props.title}</Text>
            <Text style = {props.descFont}>{props.desc}</Text>
        </View>
    )

    const Header = (props) => (
        <View style = {props.header}>
            <Back arrow = {styles.arrow} action = {() => navigation.goBack()}/>
            <Stage 
                header = {styles.stage}
                titleFont = {[styles.h2, styles.fontColor, styles.stageTitle]}
                title = {"Stage 1"}
                descFont = {[styles.p, styles.fontColor, styles.stageDesc]}
                desc = {"1,000 to next stage"}
            />
        </View>
    )

    const [month, setMonth] = useState(numCurrMonth)
    const exercises = ["Bench press", "Squat", "Deadlift"]
    const [isChecked1, setChecked1] = useState(false)
    const [isChecked2, setChecked2] = useState(false)
    const [isChecked3, setChecked3] = useState(false)
    const [isChecked4, setChecked4] = useState(false)
    const [isChecked5, setChecked5] = useState(false)

    getMonthName = (monthNumber) => {
        const date = new Date();
        date.setMonth(monthNumber - 1);
        
        return date.toLocaleString('en-US', {
            month: 'long',
        })
    }

    const [monthText, setMonthText] = useState(getMonthName(month))

    prevDate = () => {
        if(month < 0) {
            setMonth(11)
        }
        setMonth(month - 1)
        setMonthText(getMonthName(month))
    }
    
    nextDate = () => {
        if(month > 11) {
            setMonth(0)
        }
        setMonth(month + 1)
        setMonthText(getMonthName(month))
    }

    const [firstWeight, setFirstWeight] = useState(60)
    const [firstRep, setFirstRep] = useState(5)

    const [secondWeight, setSecondWeight] = useState(70)
    const [secondRep, setSecondRep] = useState(4)

    const [thirdWeight, setThirdWeight] = useState(80)
    const [thirdRep, setThirdRep] = useState(3)

    const [fourthWeight, setFourthWeight] = useState(90)
    const [fourthRep, setFourthRep] = useState(2)

    const [fifthWeight, setFifthWeight] = useState(100)
    const [fifthRep, setFifthRep] = useState(1)

    const Body = (props) => (
        <View style = {props.body}>
            <ScrollView>
                <View style = {props.dateCont}>
                    <View style = {[props.row, props.alignCenter, props.spaceBetween]}>
                        <TouchableOpacity onPress = {props.prevDate}>
                            <AntDesign name = "left" size = {20} color = "white"/>
                        </TouchableOpacity>
                        <Text style = {props.h2}>{props.currDate}</Text>
                        <TouchableOpacity onPress = {props.nextDate}>
                            <AntDesign name = "right" size = {20} color = "white"/>
                        </TouchableOpacity>
                    </View>
                    <View style = {[props.row, props.topMargin, props.width]}>
                        <View style = {props.dateBlock}>
                            <Text style = {props.p}>Sun</Text>
                            <Text style = {props.p}>20</Text>
                        </View>
                        <View style = {props.dateBlock}>
                            <Text style = {props.p}>Mon</Text>
                            <Text style = {props.p}>21</Text>
                        </View>
                        <View style = {props.dateBlock}>
                            <Text style = {props.p}>Tue</Text>
                            <Text style = {props.p}>22</Text>
                        </View>
                        <View style = {props.dateBlock}>
                            <Text style = {[props.p, props.b]}>Wed</Text>
                            <Text style = {[props.p, props.b, {backgroundColor: "rgba(255, 255, 255, 0.2)", borderRadius: 1000, padding: 5}]}>23</Text>
                        </View>
                        <View style = {props.dateBlock}>
                            <Text style = {props.p}>Thu</Text>
                            <Text style = {props.p}>24</Text>
                        </View>
                        <View style = {props.dateBlock}>
                            <Text style = {props.p}>Fri</Text>
                            <Text style = {props.p}>25</Text>
                        </View>
                        <View style = {props.dateBlock}>
                            <Text style = {props.p}>Sat</Text>
                            <Text style = {props.p}>26</Text>
                        </View>
                    </View>
                </View>
                <View style = {[props.logCont, props.topSpacer]}>
                    <Collapse isExpanded = {true}>
                        <CollapseHeader style = {[props.row, props.spaceBetween, props.alignCenter]}>
                            <Text style = {props.h2}>{props.logTitle}</Text>
                            <AntDesign name = "down" size = {16} color = "white"/>
                        </CollapseHeader>
                        <CollapseBody>
                            <View style = {[props.row, props.spaceBetween, props.topSpacer, props.alignCenter]}>
                                <Text style = {[props.p, props.b]}>Exercise</Text>
                                <SelectDropdown
                                    data = {exercises} 
                                    onSelect = {(selectedItem, index) => {
                                        console.log(selectedItem, index)
                                    }}
                                    buttonTextAfterSelection={(selectedItem, index) => {
                                        // text represented after item is selected
                                        // if data array is an array of objects then return selectedItem.property to render after item is selected
                                        return selectedItem
                                    }}
                                    rowTextForSelection={(item, index) => {
                                        // text represented for each item in dropdown
                                        // if data array is an array of objects then return item.property to represent item in dropdown
                                        return item
                                    }}
                                    buttonStyle = {styles.input}
                                    defaultButtonText = {'Select an exercise'}
                                    buttonTextStyle = {[styles.p, styles.fontColor]}
                                    renderDropdownIcon = {isOpened => {
                                        return <Entypo style = {styles.dropdown} name = "chevron-small-down" size = {20} color = "white"/>
                                    }}
                                />
                            </View>
                            <View style = {[props.row, props.topMargin, props.logTitleCont]}>
                                <View style = {props.sets}>
                                    <Text style = {[props.p, props.b]}>Sets</Text>
                                </View>
                                <View style = {[props.weight, props.alignCenter]}>
                                    <Text style = {[props.p, props.b]}>Weight</Text>
                                </View>
                                <View style = {[props.reps, props.alignCenter]}>
                                    <Text style = {[props.p, props.b]}>Repetitions</Text>
                                </View>
                                <View style = {[props.complete, props.alignEnd]}>
                                    <Text style = {[props.p, props.b]}>Completed</Text>
                                </View>
                            </View>
                            <View style = {[props.topMargin, props.logValCont]}>
                                <View style = {props.row}>
                                    <View style = {[props.sets, props.alignCenter]}>
                                        <Text style = {props.p}>1</Text>
                                    </View>
                                    <View style = {[props.weight, props.alignCenter]}>
                                        <View style = {[styles.row, styles.alignCenter]}>
                                            <TextInput
                                                style = {[styles.p, styles.b, styles.fontColor, styles.underline]}
                                                value = {firstWeight.toString()}
                                                onChangeText = {async(firstWeight) => {
                                                    await AsyncStorage.setItem("firstWeight", firstWeight)
                                                    setFirstWeight(firstWeight)
                                                }}
                                                keyboardType = "numeric"
                                            />
                                            <Text style = {[styles.p, styles.b, styles.fontColor]}>kg</Text>
                                        </View>
                                    </View>
                                    <View style = {[props.reps, props.alignCenter]}>
                                        <TextInput
                                            style = {[styles.p, styles.b, styles.fontColor, styles.underline]}
                                            value = {firstRep.toString()}
                                            onChangeText = {async(firstRep) => {
                                                await AsyncStorage.setItem("firstRep", firstRep)
                                                setFirstRep(firstRep)
                                            }}
                                            keyboardType = "numeric"
                                        />
                                    </View>
                                    <View style = {[props.complete, props.alignCenter]}>
                                        <Checkbox style = {styles.checkbox} value = {isChecked1} onValueChange = {setChecked1}/>
                                    </View>
                                </View>
                                <View style = {[props.row, props.topMargin]}>
                                    <View style = {[props.sets, props.alignCenter]}>
                                        <Text style = {props.p}>2</Text>
                                    </View>
                                    <View style = {[props.weight, props.alignCenter]}>
                                        <View style = {[styles.row, styles.alignCenter]}>
                                            <TextInput
                                                style = {[styles.p, styles.b, styles.fontColor, styles.underline]}
                                                value = {secondWeight.toString()}
                                                onChangeText = {async(secondWeight) => {
                                                    await AsyncStorage.setItem("secondWeight", secondWeight)
                                                    setSecondWeight(secondWeight)
                                                }}
                                                keyboardType = "numeric"
                                            />
                                            <Text style = {[styles.p, styles.b, styles.fontColor]}>kg</Text>
                                        </View>
                                    </View>
                                    <View style = {[props.reps, props.alignCenter]}>
                                        <TextInput
                                            style = {[styles.p, styles.b, styles.fontColor, styles.underline]}
                                            value = {secondRep.toString()}
                                            onChangeText = {async(secondRep) => {
                                                await AsyncStorage.setItem("secondRep", secondRep)
                                                setSecondRep(secondRep)
                                            }}
                                            keyboardType = "numeric"
                                        />
                                    </View>
                                    <View style = {[props.complete, props.alignCenter]}>
                                        <Checkbox style = {styles.checkbox} value = {isChecked2} onValueChange = {setChecked2}/>
                                    </View>
                                </View>
                                <View style = {[props.row, props.topMargin]}>
                                    <View style = {[props.sets, props.alignCenter]}>
                                        <Text style = {props.p}>3</Text>
                                    </View>
                                    <View style = {[props.weight, props.alignCenter]}>
                                        <View style = {[styles.row, styles.alignCenter]}>
                                            <TextInput
                                                style = {[styles.p, styles.b, styles.fontColor, styles.underline]}
                                                value = {thirdWeight.toString()}
                                                onChangeText = {async(thirdWeight) => {
                                                    await AsyncStorage.setItem("thirdWeight", thirdWeight)
                                                    setThirdWeight(thirdWeight)
                                                }}
                                                keyboardType = "numeric"
                                            />
                                            <Text style = {[styles.p, styles.b, styles.fontColor]}>kg</Text>
                                        </View>
                                    </View>
                                    <View style = {[props.reps, props.alignCenter]}>
                                        <TextInput
                                            style = {[styles.p, styles.b, styles.fontColor, styles.underline]}
                                            value = {thirdRep.toString()}
                                            onChangeText = {async(thirdRep) => {
                                                await AsyncStorage.setItem("thirdRep", thirdRep)
                                                setThirdRep(thirdRep)
                                            }}
                                            keyboardType = "numeric"
                                        />
                                    </View>
                                    <View style = {[props.complete, props.alignCenter]}>
                                        <Checkbox style = {styles.checkbox} value = {isChecked3} onValueChange = {setChecked3}/>
                                    </View>
                                </View>
                                <View style = {[props.row, props.topMargin]}>
                                    <View style = {[props.sets, props.alignCenter]}>
                                        <Text style = {props.p}>4</Text>
                                    </View>
                                    <View style = {[props.weight, props.alignCenter]}>
                                        <View style = {[styles.row, styles.alignCenter]}>
                                            <TextInput
                                                style = {[styles.p, styles.b, styles.fontColor, styles.underline]}
                                                value = {fourthWeight.toString()}
                                                onChangeText = {async(fourthWeight) => {
                                                    await AsyncStorage.setItem("fourthWeight", fourthWeight)
                                                    setFourthWeight(fourthWeight)
                                                }}
                                                keyboardType = "numeric"
                                            />
                                            <Text style = {[styles.p, styles.b, styles.fontColor]}>kg</Text>
                                        </View>
                                    </View>
                                    <View style = {[props.reps, props.alignCenter]}>
                                        <TextInput
                                            style = {[styles.p, styles.b, styles.fontColor, styles.underline]}
                                            value = {fourthRep.toString()}
                                            onChangeText = {async(fourthRep) => {
                                                await AsyncStorage.setItem("fourthRep", fourthRep)
                                                setFourthRep(fourthRep)
                                            }}
                                            keyboardType = "numeric"
                                        />
                                    </View>
                                    <View style = {[props.complete, props.alignCenter]}>
                                        <Checkbox style = {styles.checkbox} value = {isChecked4} onValueChange = {setChecked4}/>
                                    </View>
                                </View>
                                <View style = {[props.row, props.topMargin]}>
                                    <View style = {[props.sets, props.alignCenter]}>
                                        <Text style = {props.p}>5</Text>
                                    </View>
                                    <View style = {[props.weight, props.alignCenter]}>
                                        <View style = {[styles.row, styles.alignCenter]}>
                                            <TextInput
                                                style = {[styles.p, styles.b, styles.fontColor, styles.underline]}
                                                value = {fifthWeight.toString()}
                                                onChangeText = {async(fifthWeight) => {
                                                    await AsyncStorage.setItem("fifthWeight", fifthWeight)
                                                    setFifthWeight(fifthWeight)
                                                }}
                                                keyboardType = "numeric"
                                            />
                                            <Text style = {[styles.p, styles.b, styles.fontColor]}>kg</Text>
                                        </View>
                                    </View>
                                    <View style = {[props.reps, props.alignCenter]}>
                                        <TextInput
                                            style = {[styles.p, styles.b, styles.fontColor, styles.underline]}
                                            value = {fifthRep.toString()}
                                            onChangeText = {async(fifthRep) => {
                                                await AsyncStorage.setItem("fifthRep", fifthRep)
                                                setFifthRep(fifthRep)
                                            }}
                                            keyboardType = "numeric"
                                        />
                                    </View>
                                    <View style = {[props.complete, props.alignCenter]}>
                                        <Checkbox style = {styles.checkbox} value = {isChecked5} onValueChange = {setChecked5}/>
                                    </View>
                                </View>
                            </View>
                        </CollapseBody>
                    </Collapse>
                    <Collapse isExpanded = {false} style = {props.topSpacer}>
                        <CollapseHeader style = {[props.row, props.spaceBetween, props.alignCenter]}>
                            <Text style = {props.h2}>{props.notableTitle}</Text>
                            <AntDesign name = "down" size = {16} color = "white"/>
                        </CollapseHeader>
                        <CollapseBody>
                            <View style = {[props.activityCont, props.topSpacer]}>
                                <View style = {props.row}>
                                    <View style = {props.activityIcon}>
                                        <Entypo name = "stopwatch" size = {30} color = "white"/>
                                    </View>
                                    <View style = {props.activityContent}>
                                        <Text style = {[props.p, props.b, props.fontColor]}>30 : 00</Text>
                                        <Text style = {[props.p, props.fontColor]}>minutes</Text>
                                    </View>
                                </View>
                                <View style = {[props.row, props.topMargin]}>
                                    <View style = {props.activityIcon}>
                                        <MaterialCommunityIcons name = "lightning-bolt" size = {30} color = "white"/>
                                    </View>
                                    <View style = {props.activityContent}>
                                        <Text style = {[props.p, props.b, props.fontColor]}>300</Text>
                                        <Text style = {[props.p, props.fontColor]}>calories burnt</Text>
                                    </View>
                                </View>
                                <View style = {[props.row, props.topMargin]}>
                                    <View style = {props.activityIcon}>
                                        <MaterialCommunityIcons name = "arm-flex" size = {30} color = "white"/>
                                    </View>
                                    <View style = {props.activityContent}>
                                        <Text style = {[props.p, props.b, props.fontColor]}>2</Text>
                                        <Text style = {[props.p, props.fontColor]}>new personal records</Text>
                                    </View>
                                </View>
                            </View>
                        </CollapseBody>
                    </Collapse>
                </View>
            </ScrollView>
        </View>
    )

    return (
        <SafeAreaView style = {styles.safeAreaContainer}>
            <View style = {styles.container}>
                <LinearGradient colors = {['rgba(232, 69, 69, 1)', 'rgba(43, 46, 74, 1)']} style = {styles.bg}>
                    <Header header = {styles.header}/>
                    <Body 
                        body = {styles.body}
                        dateCont = {styles.dateCont}
                        row = {styles.row}
                        alignCenter = {styles.alignCenter}
                        alignEnd = {styles.alignEnd}
                        justifyEnd = {styles.justifyEnd}
                        spaceBetween = {styles.spaceBetween}
                        topSpacer = {styles.topSpacer}
                        topMargin = {styles.topMargin}
                        h2 = {[styles.h2, styles.fontColor]}
                        p = {[styles.p, styles.fontColor]}
                        b = {styles.b}
                        currDate = {`${monthText}, ${currYear}`}
                        prevDate = {prevDate}
                        nextDate = {nextDate}
                        width = {styles.dateWidth}
                        dateBlock = {styles.dateBlock}
                        logTitle = {"Progress log"}
                        checkbox = {styles.checkbox}
                        flex = {styles.flex}
                        sets = {styles.setCont}
                        weight = {styles.weightCont}
                        reps = {styles.repCont}
                        complete = {styles.completed}
                        logTitleCont = {styles.logTitleCont}
                        notableTitle = {"Activity log"}
                        activityCont = {styles.activityCont}
                        activityIcon = {styles.activityIcon}
                        activityContent = {styles.activityContent}
                    />
                </LinearGradient>
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    safeAreaContainer: {
        flex: 1,
    },
    container: {
        flex: 1,
    },
    bg: {
        flex: 1,
    },
    h1: {
        fontSize: 30,
        fontWeight: "bold",
    },
    h2: {
        fontSize: 20,
        fontWeight: "bold",
    },
    p: {
        fontSize: 16,
    },
    p1: {
        fontSize: 12,
    },
    b: {
        fontWeight: "bold",
    },
    fontColor: {
        color: "white",
    },
    centerText: {
        textAlign: "center",
    },
    topSpacer: {
        marginTop: "10%",
    },
    topMargin: {
        marginTop: "5%",
    },
    leftMargin: {
        marginLeft: "5%",
    },
    rightMargin: {
        marginRight: "5%",
    },
    alignCenter: {
        alignItems: "center",
    },
    alignEnd: {
        alignItems: "flex-end",
    },
    justifyEnd: {
        justifyContent: "flex-end",
    },
    row: {
        flexDirection: "row",
    },
    flex: {
        flex: 1,
    },
    spaceBetween: {
        justifyContent: "space-between",
    },
    header: {
        flexDirection: "row",
        paddingHorizontal: "10%",
        paddingTop: "15%",
        paddingBottom: "3%",
        alignItems: "center",
    },
    arrow: {
        width: 36,
        height: 36,
        zIndex: 100,
        justifyContent: "center",
        alignItems: "center",
    },
    stage: {
        width: "100%",
        position: "absolute",
        left: "12.5%",
        bottom: 0,
        alignItems: "center",
        opacity: 0,
    },
    stageTitle: {
        paddingHorizontal: 16,
        paddingVertical: 5,
        borderRadius: 1000,
        backgroundColor: "rgba(66, 72, 116, 1)",
        marginBottom: "-2.5%",
        zIndex: 100,
    },
    stageDesc: {
        paddingHorizontal: 16,
        paddingVertical: 8,
        borderRadius: 1000,
        backgroundColor: "rgba(255, 255, 255, 0.4)",
        zIndex: 99,
    },
    body: {
        flex: 1,
        paddingTop: "10%",
        paddingBottom: "15%",
        paddingHorizontal: "10%",
    },
    dateWidth: {
        width: "95%",
        alignSelf: "center",
    },
    dateBlock: {
        flex: 1,
        height: 50,
        justifyContent: "center",
        alignItems: "center",
    },
    input: {
        flex: 1,
        height: 40,
        borderRadius: 12,
        backgroundColor: "rgba(255, 255, 255, 0.2)",
        marginRight: "10%",
    },
    dropdown: {
        paddingLeft: 8,
        borderLeftWidth: 1,
        borderColor: "white",
    },
    setCont: {
        flex: 0.4,
    },
    weightCont: {
        flex: 0.6,
    },
    repCont: {
        flex: 1,
    },
    completed: {
        flex: 0.8,
    },
    checkbox: {
        borderRadius: 5,
        backgroundColor: "rgba(255, 255, 255, 0.2)",
        borderWidth: 1,
        borderColor: "white",
    },
    activityIcon: {
        width: 60,
        height: 60,
        backgroundColor: "rgba(255, 255, 255, 0.2)",
        borderWidth: 1,
        borderColor: "white",
        borderRadius: 1000,
        justifyContent: "center",
        alignItems: "center",
    },
    activityContent: {
        flex: 1,
        paddingHorizontal: "10%",
        justifyContent: "center",
    },
    underline: {
        textDecorationLine: "underline",
    }
})