import { StyleSheet, Text, View, SafeAreaView, TouchableOpacity, Image } from 'react-native'
import SwipeUpDown from 'react-native-swipe-up-down'
import { LinearGradient } from 'expo-linear-gradient'
import { Ionicons, MaterialIcons, MaterialCommunityIcons, FontAwesome5, Feather } from '@expo/vector-icons'

export default function Home({navigation}) {
    const Burger = (props) => (
        <TouchableOpacity style = {props.burger} onPress = {props.action}>
            <Ionicons name = "ios-menu" size = {30} color = "white" />
        </TouchableOpacity>
    )

    const Stage = (props) => (
        <View style = {props.header}>
            <Text style = {props.titleFont}>{props.title}</Text>
            <Text style = {props.descFont}>{props.desc}</Text>
        </View>
    )

    const Header = (props) => (
        <View style = {props.header}>
            <Burger burger = {styles.burger} action = {() => navigation.navigate("menu")}/>
            <Stage 
                header = {styles.stage}
                titleFont = {[styles.h2, styles.fontColor, styles.stageTitle]}
                title = {"Stage 1"}
                descFont = {[styles.p, styles.fontColor, styles.stageDesc]}
                desc = {"1,000 to next stage"}
            />
        </View>
    )
    
    const QuickAccess = (props) => (
        <View style = {props.quickCont}>
            <TouchableOpacity style = {props.button} onPress = {props.link1}>
                <Feather name = "book-open" size = {24} color = "white"/>
            </TouchableOpacity>
            <TouchableOpacity style = {[props.button, props.buttonSpacer]} onPress = {props.link2}>
                <MaterialIcons name = "leaderboard" size = {24} color = "white"/>
            </TouchableOpacity>
            <TouchableOpacity style = {props.button} onPress = {props.link3}>
                <MaterialCommunityIcons name = "sack" size = {24} color = "white"/>
            </TouchableOpacity>
        </View>
    )

    const Body = (props) => (
        <View style = {props.body}>
            <Image style = {props.board} source = {require("../assets/board.png")}/>
            <QuickAccess 
                quickCont = {styles.quickCont}
                button = {styles.button}
                buttonSpacer = {styles.buttonSpacer}
                link1 = {() => navigation.navigate("log")}
                link2 = {() => navigation.navigate("leaderboards")}
                link3 = {() => navigation.navigate("rewards")}
            />
        </View>
    )

    const Draggable = (props) => (
        <SwipeUpDown
            itemMini = {
                <View style = {props.mini}>
                    <View style = {props.indicator}/>
                    <View style = {props.textCont}>
                        <Text style = {props.h2}>{props.welcome}</Text>
                        <Text style = {props.p}>{props.prompt}</Text>
                    </View>
                </View>
            }
            itemFull = {
                <View style = {props.full}>
                    <View style = {props.indicator}/>
                    <View style = {props.fullCont}>
                        <View style = {[props.row, props.spaceBetween]}>
                            <Text style = {props.h2}>Your daily tasks</Text>
                            <Text style = {props.h2}>(0/3)</Text>
                        </View>
                        <View style = {[props.row, props.topSpacer, props.alignCenter]}>
                            <View style = {props.icon}>
                                <Image style = {[props.img, {aspectRatio: 567/588}]} source = {require("../assets/bench.png")}/>
                            </View>
                            <View style = {[props.content, props.row]}>
                                <View style = {props.info}>
                                    <Text style = {[props.p, props.b, props.exTitle]}>Barbell bench press</Text>
                                    <Text style = {props.p1}>Perform 5 sets of 5 reps @ 60kg.</Text>
                                </View>
                                <View style = {props.click}>
                                    <Text style = {[props.p1]}>+30 points</Text>
                                    <TouchableOpacity onPress = {props.action}>
                                        <Text style = {[props.p1, props.redeem]}>Start</Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        </View>
                        <View style = {[props.row, props.topMargin, props.alignCenter]}>
                            <View style = {props.icon}>
                                <Image style = {[props.img, {aspectRatio: 372/513}]} source = {require("../assets/overhead.png")}/>
                            </View>
                            <View style = {[props.content, props.row]}>
                                <View style = {props.info}>
                                    <Text style = {[props.p, props.b, props.exTitle]}>Military press</Text>
                                    <Text style = {props.p1}>Perform 5 sets of 8 reps @ 40kg.</Text>
                                </View>
                                <View style = {props.click}>
                                    <Text style = {[props.p1]}>+30 points</Text>
                                    <TouchableOpacity onPress = {props.action}>
                                        <Text style = {[props.p1, props.redeem]}>Start</Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        </View>
                        <View style = {[props.row, props.topMargin, props.alignCenter]}>
                            <View style = {props.icon}>
                                <MaterialCommunityIcons name = "dumbbell" size = {30} color = "white"/>
                            </View>
                            <View style = {[props.content, props.row]}>
                                <View style = {props.info}>
                                    <Text style = {[props.p, props.b, props.exTitle]}>Bicep curls</Text>
                                    <Text style = {props.p1}>Perform 3 sets of 15 reps @ 10kg.</Text>
                                </View>
                                <View style = {props.click}>
                                    <Text style = {[props.p1]}>+30 points</Text>
                                    <TouchableOpacity onPress = {props.action}>
                                        <Text style = {[props.p1, props.redeem]}>Start</Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        </View>
                        <View style = {[props.row, props.spaceBetween, props.topSpacer]}>
                            <Text style = {props.h2}>Extra challenges</Text>
                            <Text style = {props.h2}>(0/1)</Text>
                        </View>
                        <View style = {[props.row, props.topMargin, props.alignCenter]}>
                            <View style = {props.icon}>
                                <FontAwesome5 name = "walking" size = {30} color = "white"/>
                            </View>
                            <View style = {[props.content, props.row]}>
                                <View style = {props.info}>
                                    <Text style = {[props.p, props.b, props.exTitle]}>Walking (treadmill)</Text>
                                    <Text style = {props.p1}>Walk for 30 mins.</Text>
                                </View>
                                <View style = {props.click}>
                                    <Text style = {[props.p1]}>+10 points</Text>
                                    <TouchableOpacity onPress = {props.action}>
                                        <Text style = {[props.p1, props.redeem]}>Start</Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        </View>
                    </View>
                </View>
            }
            onShowMini = {() => console.log('mini')}
            onShowFull = {() => console.log('full')}
            extraMarginTop = {24}
            disableSwipeIcon = {true}
            animation = {"easeInEaseOut"}
            style = {props.draggable}
            swipeHeight = {110}
        />
    )

    return(
        <SafeAreaView style = {styles.safeAreaContainer}>
            <View style = {styles.container}>
                <LinearGradient colors = {['rgba(232, 69, 69, 1)', 'rgba(43, 46, 74, 1)']} style = {styles.bg}>
                    <Header header = {styles.header}/>
                    <Body body = {styles.body} board = {styles.board}/>
                    <Draggable 
                        draggable = {styles.drag} 
                        mini = {styles.mini} 
                        full = {styles.full}
                        indicator = {styles.indicator}
                        h2 = {[styles.h2, styles.fontColor]}
                        p = {[styles.p, styles.fontColor]}
                        p1 = {[styles.p1, styles.fontColor]}
                        b = {styles.b}
                        welcome = {"Welcome back, Isaac!"}
                        prompt = {"Swipe up for your daily challenges!"}
                        textCont = {styles.text}
                        fullCont = {styles.fullCont}
                        row = {styles.row}
                        spaceBetween = {styles.spaceBetween}
                        icon = {styles.icon}
                        content = {styles.content}
                        topSpacer = {styles.topSpacer}
                        topMargin = {styles.topMargin}
                        img = {styles.img}
                        info = {styles.info}
                        click = {styles.click}
                        exTitle = {styles.exTitle}
                        alignCenter = {styles.alignCenter}
                        redeem = {styles.redeem}
                        action = {() => navigation.navigate("cam")}
                    />
                </LinearGradient>
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    safeAreaContainer: {
        flex: 1,
    },
    container: {
        flex: 1,
    },
    bg: {
        flex: 1,
    },
    h1: {
        fontSize: 30,
        fontWeight: "bold",
    },
    h2: {
        fontSize: 20,
        fontWeight: "bold",
    },
    p: {
        fontSize: 16,
    },
    p1: {
        fontSize: 12,
    },
    b: {
        fontWeight: "bold",
    },
    fontColor: {
        color: "white",
    },
    centerText: {
        textAlign: "center",
    },
    topSpacer: {
        marginTop: "10%",
    },
    topMargin: {
        marginTop: "5%",
    },
    leftMargin: {
        marginLeft: "5%",
    },
    rightMargin: {
        marginRight: "5%",
    },
    alignCenter: {
        alignItems: "center",
    },
    header: {
        flexDirection: "row",
        paddingHorizontal: "10%",
        paddingTop: "15%",
        paddingBottom: "3%",
        alignItems: "center",
    },
    burger: {
        width: 36,
        height: 36,
        zIndex: 100,
        justifyContent: "center",
        alignItems: "center",
    },
    stage: {
        width: "100%",
        position: "absolute",
        left: "12.5%",
        bottom: 0,
        alignItems: "center",
        opacity: 0,
    },
    stageTitle: {
        paddingHorizontal: 16,
        paddingVertical: 5,
        borderRadius: 1000,
        backgroundColor: "rgba(66, 72, 116, 1)",
        marginBottom: "-2.5%",
        zIndex: 100,
    },
    stageDesc: {
        paddingHorizontal: 16,
        paddingVertical: 8,
        borderRadius: 1000,
        backgroundColor: "rgba(255, 255, 255, 0.4)",
        zIndex: 99,
    },
    body: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
    },
    board: {
        width: "65%",
        height: "65%",
        aspectRatio: 1264/2016,
        marginBottom: "20%",
        marginLeft: "20%",
    },
    quickCont: {
        position: "absolute",
        right: "10%",
        bottom: "25%",
        justifyContent: "space-between",
    },
    button: {
        width: 45,
        height: 45,
        borderRadius: 1000,
        backgroundColor: "rgba(166, 177, 225, 0.6)",
        justifyContent: "center",
        alignItems: "center",
    },
    buttonSpacer: {
        marginVertical: "5%",
    },
    drag: {
        paddingHorizontal: "10%",
        backgroundColor: "rgba(66, 72, 116, 1)",
    },
    indicator: {
        width: "50%",
        height: 4,
        backgroundColor: "rgba(244, 238, 255, 1)",
        borderRadius: 1000,
        alignSelf: "center",
        marginTop: 8,
    },
    text: {
        justifyContent: "center",
        alignItems: "center",
        marginTop: "8%",
    },
    fullCont: {
        marginTop: "8%",
    },
    spaceBetween: {
        justifyContent: "space-between",
    },
    row: {
        flexDirection: "row",
    },
    icon: {
        width: 60,
        height: 60,
        justifyContent: "center",
        alignItems: "center",
        borderWidth: 1,
        borderRadius: 1000,
        borderColor: "#fff",
        marginRight: "5%",
    },
    content: {
        flex: 1,
    },
    img: {
        width: 30,
        height: 30,
    },
    info: {
        flex: 1,
        justifyContent: "center",
    },
    click: {
        flex: 0.45,
        justifyContent: "center",
        alignItems: "flex-end",
    },
    exTitle: {
        marginBottom: "2.5%",
    },
    redeem: {
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: 1000,
        backgroundColor: "rgba(166, 177, 225, 0.75)",
        marginTop: "10%",
    }
})