import { StyleSheet, Text, View, SafeAreaView, TouchableOpacity, TextInput, ScrollView } from 'react-native'
import 'react-native-gesture-handler'
import { Ionicons, AntDesign, Entypo } from '@expo/vector-icons'
import { useState } from "react"
import { LinearGradient } from 'expo-linear-gradient'
import { Collapse, CollapseHeader, CollapseBody } from "accordion-collapse-react-native"
import SelectDropdown from 'react-native-select-dropdown'
import { RadioButton } from 'react-native-paper'

export default function Calculator({navigation}) {
    const Back = (props) => (
        <TouchableOpacity style = {props.arrow} onPress = {props.action}>
            <Ionicons name = "ios-arrow-back" size = {30} color = "white"/>
        </TouchableOpacity>
    )

    const Stage = (props) => (
        <View style = {props.header}>
            <Text style = {props.titleFont}>{props.title}</Text>
            <Text style = {props.descFont}>{props.desc}</Text>
        </View>
    )

    const Header = (props) => (
        <View style = {props.header}>
            <Back arrow = {styles.arrow} action = {() => navigation.goBack()}/>
            <Stage 
                header = {styles.stage}
                titleFont = {[styles.h2, styles.fontColor, styles.stageTitle]}
                title = {"Stage 1"}
                descFont = {[styles.p, styles.fontColor, styles.stageDesc]}
                desc = {"1,000 to next stage"}
            />
        </View>
    )

    const Option = (props) => {
        const [checked, setChecked] = useState("first")
        return (
            <View style = {[props.row, props.alignCenter]}>
                <Text style = {[props.p, props.b, props.rightMargin]}>M</Text>
                <RadioButton
                    value = "first"
                    status = { checked === 'first' ? 'checked' : 'unchecked' }
                    onPress = {() => setChecked('first')}
                    color = "white"
                    uncheckedColor = "#cbcbcb"
                />
                <Text style = {[props.p, props.b, props.rightMargin, props.leftSpacer]}>F</Text>
                <RadioButton
                    value = "second"
                    status = { checked === 'second' ? 'checked' : 'unchecked' }
                    onPress = {() => setChecked('second')}
                    color = "white"
                    uncheckedColor = "#cbcbcb"
                />
            </View>
        )
    }

    const exercises = ["Bench press", "Squat", "Deadlift"]
    const [weight, onChangeWeight] = useState("")
    const [reps, onChangeReps] = useState("")
    const [age, onChangeAge] = useState("")
    const [BMRweight, onChangeBMRW] = useState("")
    const [BMRheight, onChangeBMRH] = useState("")    

    const Body = (props) => (
        <View style = {props.body}>
            <Collapse isExpanded = {true}>
                <CollapseHeader>
                    <View style = {[props.row, props.spaceBetween, props.alignCenter]}>
                        <Text style = {props.h2}>One rep max calculator (1RM)</Text>
                        <AntDesign name = "down" size = {16} color = "white"/>
                    </View>
                </CollapseHeader>
                <CollapseBody style = {props.topSpacer}>
                    <View style = {[props.row, props.spaceBetween, props.alignCenter]}>
                        <Text style = {[props.p, props.b]}>Exercise</Text>
                        <SelectDropdown
                            data = {exercises} 
                            onSelect = {(selectedItem, index) => {
                                console.log(selectedItem, index)
                            }}
                            buttonTextAfterSelection={(selectedItem, index) => {
                                // text represented after item is selected
                                // if data array is an array of objects then return selectedItem.property to render after item is selected
                                return selectedItem
                            }}
                            rowTextForSelection={(item, index) => {
                                // text represented for each item in dropdown
                                // if data array is an array of objects then return item.property to represent item in dropdown
                                return item
                            }}
                            buttonStyle = {styles.selectInput}
                            defaultButtonText = {'Select an exercise'}
                            buttonTextStyle = {[styles.p, styles.fontColor]}
                            renderDropdownIcon = {isOpened => {
                                return <Entypo style = {styles.dropdown} name = "chevron-small-down" size = {20} color = "white"/>
                            }}
                        />
                    </View>
                    <View style = {[props.row, props.spaceBetween, props.alignCenter, props.justifyEnd, props.topMargin]}>
                        <Text style = {[props.p, props.b, props.sectionTitle]}>Weight</Text>
                        <TextInput
                            style = {[props.input, props.inputPadding, props.p]}
                            onChangeText = {onChangeWeight}
                            value = {weight}
                            placeholder = {"Weight (kg)"}
                            placeholderTextColor = {"#fff"}
                            keyboardType = "numeric"
                        />
                    </View>
                    <View style = {[props.row, props.spaceBetween, props.alignCenter, props.justifyEnd, props.topMargin]}>
                        <Text style = {[props.p, props.b, props.sectionTitle]}>Repetitions</Text>
                        <TextInput
                            style = {[props.input, props.inputPadding, props.p]}
                            onChangeText = {onChangeReps}
                            value = {weight}
                            placeholder = {"Number of repetitions"}
                            placeholderTextColor = {"#fff"}
                            keyboardType = "numeric"
                        />
                    </View>
                    <TouchableOpacity style = {[props.submit, props.topSpacer, props.alignCenter]}>
                        <Text style = {[props.p, props.b]}>Calculate</Text>
                    </TouchableOpacity>
                </CollapseBody>
            </Collapse>
            <Collapse isExpanded = {false} style = {props.topSpacer}>
                <CollapseHeader>
                    <View style = {[props.row, props.spaceBetween, props.alignCenter]}>
                        <Text style = {props.h2}>Metabolic rate calculator</Text>
                        <AntDesign name = "down" size = {16} color = "white"/>
                    </View>
                </CollapseHeader>
                <CollapseBody style = {props.topSpacer}>
                    <View style = {[props.row, props.spaceBetween, props.alignCenter, props.justifyEnd, props.topMargin]}>
                        <Text style = {[props.p, props.b, props.sectionTitle]}>Age</Text>
                        <TextInput
                            style = {[props.input, props.inputPadding, props.p]}
                            onChangeText = {onChangeAge}
                            value = {weight}
                            placeholder = {"Age"}
                            placeholderTextColor = {"#fff"}
                            keyboardType = "numeric"
                        />
                    </View>
                    <View style = {[props.row, props.spaceBetween, props.alignCenter, props.topMargin]}>
                        <Text style = {[props.p, props.b, props.sectionTitle]}>Gender</Text>
                        <Option
                            row = {styles.row}
                            p = {[styles.p, styles.fontColor]}
                            b = {styles.b}
                            alignCenter = {styles.alignCenter}
                            rightMargin = {styles.rightMargin}
                            leftSpacer = {styles.leftSpacer}
                        />
                    </View>
                    <View style = {[props.row, props.spaceBetween, props.alignCenter, props.justifyEnd, props.topMargin]}>
                        <Text style = {[props.p, props.b, props.sectionTitle]}>Weight</Text>
                        <TextInput
                            style = {[props.input, props.inputPadding, props.p]}
                            onChangeText = {onChangeBMRW}
                            value = {weight}
                            placeholder = {"Weight (kg)"}
                            placeholderTextColor = {"#fff"}
                            keyboardType = "numeric"
                        />
                    </View>
                    <View style = {[props.row, props.spaceBetween, props.alignCenter, props.justifyEnd, props.topMargin]}>
                        <Text style = {[props.p, props.b, props.sectionTitle]}>Height</Text>
                        <TextInput
                            style = {[props.input, props.inputPadding, props.p]}
                            onChangeText = {onChangeBMRH}
                            value = {weight}
                            placeholder = {"Height (cm)"}
                            placeholderTextColor = {"#fff"}
                            keyboardType = "numeric"
                        />
                    </View>
                    <TouchableOpacity style = {[props.submit, props.topSpacer, props.alignCenter]}>
                        <Text style = {[props.p, props.b]}>Calculate</Text>
                    </TouchableOpacity>
                </CollapseBody>
            </Collapse>
        </View>
    )

    return (
        <SafeAreaView style = {styles.safeAreaContainer}>
            <View style = {styles.container}>
                <LinearGradient colors = {['rgba(232, 69, 69, 1)', 'rgba(43, 46, 74, 1)']} style = {styles.bg}>
                    <ScrollView>
                        <Header header = {styles.header}/>
                        <Body
                            body = {styles.body}
                            row = {styles.row}
                            h2 = {[styles.h2, styles.fontColor]}
                            p = {[styles.p, styles.fontColor]}
                            p1 = {[styles.p, styles.fontColor]}
                            b = {styles.b}
                            spaceBetween = {styles.spaceBetween}
                            alignCenter = {styles.alignCenter}
                            topMargin = {styles.topMargin}
                            topSpacer = {styles.topSpacer}
                            justifyEnd = {styles.justifyEnd}
                            input = {styles.input}
                            inputPadding = {styles.inputPadding}
                            sectionTitle = {styles.sectionTitle}
                            submit = {styles.submit}
                        />
                    </ScrollView>
                </LinearGradient>
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    safeAreaContainer: {
        flex: 1,
    },
    container: {
        flex: 1,
    },
    bg: {
        flex: 1,
    },
    h1: {
        fontSize: 30,
        fontWeight: "bold",
    },
    h2: {
        fontSize: 20,
        fontWeight: "bold",
    },
    p: {
        fontSize: 16,
    },
    p1: {
        fontSize: 12,
    },
    b: {
        fontWeight: "bold",
    },
    fontColor: {
        color: "white",
    },
    centerText: {
        textAlign: "center",
    },
    topSpacer: {
        marginTop: "10%",
    },
    topMargin: {
        marginTop: "5%",
    },
    leftMargin: {
        marginLeft: "5%",
    },
    rightMargin: {
        marginRight: "5%",
    },
    leftSpacer: {
        marginLeft: "15%",
    },
    alignCenter: {
        alignItems: "center",
    },
    alignEnd: {
        alignItems: "flex-end",
    },
    justifyEnd: {
        justifyContent: "flex-end",
    },
    row: {
        flexDirection: "row",
    },
    flex: {
        flex: 1,
    },
    spaceBetween: {
        justifyContent: "space-between",
    },
    header: {
        flexDirection: "row",
        paddingHorizontal: "10%",
        paddingTop: "15%",
        paddingBottom: "3%",
        alignItems: "center",
    },
    arrow: {
        width: 36,
        height: 36,
        zIndex: 100,
        justifyContent: "center",
        alignItems: "center",
    },
    stage: {
        width: "100%",
        position: "absolute",
        left: "12.5%",
        bottom: 0,
        alignItems: "center",
        opacity: 0,
    },
    stageTitle: {
        paddingHorizontal: 16,
        paddingVertical: 5,
        borderRadius: 1000,
        backgroundColor: "rgba(66, 72, 116, 1)",
        marginBottom: "-2.5%",
        zIndex: 100,
    },
    stageDesc: {
        paddingHorizontal: 16,
        paddingVertical: 8,
        borderRadius: 1000,
        backgroundColor: "rgba(255, 255, 255, 0.4)",
        zIndex: 99,
    },
    body: {
        flex: 1,
        paddingTop: "10%",
        paddingBottom: "15%",
        paddingHorizontal: "10%",
    },
    selectInput: {
        flex: 1,
        height: 40,
        borderRadius: 12,
        backgroundColor: "rgba(255, 255, 255, 0.2)",
        marginRight: "10%",
    },
    input: {
        flex: 1,
        height: 40,
        borderRadius: 12,
        backgroundColor: "rgba(255, 255, 255, 0.2)",
    },
    inputPadding: {
        paddingHorizontal: 16,
    },
    dropdown: {
        paddingLeft: 8,
        borderLeftWidth: 1,
        borderColor: "white",
    },
    sectionTitle: {
        flex: 0.5,
    },
    submit: {
        backgroundColor: "rgba(166, 177, 225, 0.75)",
        borderRadius: 12,
        paddingHorizontal: 16,
        paddingVertical: 8,
    }
})