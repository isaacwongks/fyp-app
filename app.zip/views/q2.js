import { StyleSheet, Text, View, SafeAreaView, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function Start({navigation}) {
    const Option = (props) => (
        <TouchableOpacity style = {props.button} onPress = {props.action}>
            <Text style = {props.font}>{props.text}</Text>
        </TouchableOpacity>
    )

    return(
        <SafeAreaView style = {styles.safeAreaContainer}>
            <View style = {styles.container}>
                <LinearGradient colors = {['rgba(232, 69, 69, 1)', 'rgba(43, 46, 74, 1)']} style = {styles.bg}>
                    <Text style = {[styles.h1, styles.fontColor, styles.question]}>How long do you spend on your workouts per session?</Text>
                    <Text style = {[styles.p, styles.fontColor, styles.prompt]}>*Choose one that best describes you</Text>
                    <Option
                        button = {[styles.button, styles.topSpacer]}
                        font = {[styles.p, styles.centerText, styles.fontColor, styles.b]}
                        text = {"Never"}
                        action = {() => navigation.navigate("form")}
                    />
                    <Option
                        button = {[styles.button, styles.topMargin]}
                        font = {[styles.p, styles.centerText, styles.fontColor, styles.b]}
                        text = {"15 - 30 mins"}
                        action = {() => navigation.navigate("form")}
                    />
                    <Option
                        button = {[styles.button, styles.topMargin]}
                        font = {[styles.p, styles.centerText, styles.fontColor, styles.b]}
                        text = {"30 mins - 1 hour"}
                        action = {() => navigation.navigate("form")}
                    />
                    <Option
                        button = {[styles.button, styles.topMargin]}
                        font = {[styles.p, styles.centerText, styles.fontColor, styles.b]}
                        text = {"More than 1 hour"}
                        action = {() => navigation.navigate("form")}
                    />
                </LinearGradient>
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    safeAreaContainer: {
        flex: 1,
    },
    container: {
        flex: 1,
    },
    bg: {
        flex: 1,
        padding: "10%",
        alignItems: "center",
        justifyContent: "center",
    },
    h1: {
        fontSize: 30,
        fontWeight: "bold",
    },
    p: {
        fontSize: 16,
    },
    b: {
        fontWeight: "bold",
    },
    fontColor: {
        color: "white",
    },
    centerText: {
        textAlign: "center",
    },
    question: {
        width: "80%",
    },
    prompt: {
        width: "80%",
        marginTop: "2.5%",
    },
    button: {
        width: "80%",
        paddingHorizontal: 16,
        paddingVertical: 8,
        backgroundColor: "rgba(166, 177, 225, 0.75)",
        borderRadius: 1000,
    },
    topSpacer: {
        marginTop: "10%",
    },
    topMargin: {
        marginTop: "5%",
    }
})