import { StyleSheet, Text, View, SafeAreaView, TouchableOpacity, Image, ScrollView } from 'react-native';
import 'react-native-gesture-handler';
import { Ionicons, AntDesign, Feather, FontAwesome5, MaterialIcons, MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

export default function Menu({navigation}) {
    const Back = (props) => (
        <TouchableOpacity style = {props.arrow} onPress = {props.action}>
            <Ionicons name = "ios-arrow-back" size = {30} color = "white"/>
        </TouchableOpacity>
    )

    const Stage = (props) => (
        <View style = {props.header}>
            <Text style = {props.titleFont}>{props.title}</Text>
            <Text style = {props.descFont}>{props.desc}</Text>
        </View>
    )

    const Header = (props) => (
        <View style = {props.header}>
            <Back arrow = {styles.arrow} action = {() => navigation.goBack()}/>
            <Stage 
                header = {styles.stage}
                titleFont = {[styles.h2, styles.fontColor, styles.stageTitle]}
                title = {"Stage 1"}
                descFont = {[styles.p, styles.fontColor, styles.stageDesc]}
                desc = {"1,000 to next stage"}
            />
        </View>
    )

    const Body = (props) => (
        <View style = {props.body}>
            <View style = {props.dashboardCont}>
                <Text style = {props.h2}>{props.dashboardTitle}</Text>
                <TouchableOpacity style = {[props.row, props.topSpacer]}>
                    <View style = {props.pfpCont}>
                        <Image style = {[props.pfp, {aspectRatio: 234/283}]} source = {require("../assets/pfp.png")}/>
                    </View>
                    <View style = {[props.row, props.alignCenter, props.pfContent]}>
                        <View style = {props.pfDesc}>
                            <Text style = {[props.p, props.b]}>{props.user}</Text>
                            <Text style = {props.p1}>Show profile</Text>
                        </View>
                        <AntDesign name = "right" size = {20} color = "white"/>
                    </View>
                </TouchableOpacity>
                <Text style = {[props.h2, props.topSpacer]}>{props.menuTitle}</Text>
                <TouchableOpacity style = {[props.row, props.topSpacer]} onPress = {props.link1}>
                    <View style = {props.iconCont}>
                        <Feather name = "book-open" size = {24} color = "white"/>
                    </View>
                    <View style = {[props.row, props.alignCenter, props.itemContent]}>
                        <Text style = {[props.p, props.b, props.leftMargin]}>{props.item1}</Text>
                        <AntDesign name = "right" size = {20} color = "white"/>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity style = {[props.row, props.topMargin]} onPress = {props.link2}>
                    <View style = {props.iconCont}>
                        <FontAwesome5 name = "walking" size = {24} color = "white"/>
                    </View>
                    <View style = {[props.row, props.alignCenter, props.itemContent]}>
                        <Text style = {[props.p, props.b, props.leftMargin]}>{props.item2}</Text>
                        <AntDesign name = "right" size = {20} color = "white"/>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity style = {[props.row, props.topMargin]} onPress = {props.link3}>
                    <View style = {props.iconCont}>
                        <MaterialIcons name = "leaderboard" size = {30} color = "white"/>
                    </View>
                    <View style = {[props.row, props.alignCenter, props.itemContent]}>
                        <Text style = {[props.p, props.b, props.leftMargin]}>{props.item3}</Text>
                        <AntDesign name = "right" size = {20} color = "white"/>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity style = {[props.row, props.topMargin]} onPress = {props.link4}>
                    <View style = {props.iconCont}>
                        <MaterialCommunityIcons name = "sack" size = {30} color = "white"/>
                    </View>
                    <View style = {[props.row, props.alignCenter, props.itemContent]}>
                        <Text style = {[props.p, props.b, props.leftMargin]}>{props.item4}</Text>
                        <AntDesign name = "right" size = {20} color = "white"/>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity style = {[props.row, props.topMargin]} onPress = {props.link5}>
                    <View style = {props.iconCont}>
                        <Ionicons name = "calculator" size = {24} color = "white"/>
                    </View>
                    <View style = {[props.row, props.alignCenter, props.itemContent]}>
                        <Text style = {[props.p, props.b, props.leftMargin]}>{props.item5}</Text>
                        <AntDesign name = "right" size = {20} color = "white"/>
                    </View>
                </TouchableOpacity>
                <Text style = {[props.h2, props.topSpacer]}>Other features</Text>
                <TouchableOpacity style = {[props.row, props.topMargin]} onPress = {props.link6}>
                    <View style = {props.iconCont}>
                        <MaterialCommunityIcons name = "bell-alert" size = {24} color = "white"/>
                    </View>
                    <View style = {[props.row, props.alignCenter, props.itemContent]}>
                        <Text style = {[props.p, props.b, props.leftMargin]}>{props.other1}</Text>
                        <AntDesign name = "right" size = {20} color = "white"/>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity style = {[props.row, props.topMargin]} onPress = {props.link7}>
                    <View style = {props.iconCont}>
                        <Ionicons name = "md-document-text" size = {24} color = "white"/>
                    </View>
                    <View style = {[props.row, props.alignCenter, props.itemContent]}>
                        <Text style = {[props.p, props.b, props.leftMargin]}>{props.other2}</Text>
                        <AntDesign name = "right" size = {20} color = "white"/>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity style = {[props.row, props.topMargin]} onPress = {props.link8}>
                    <View style = {props.iconCont}>
                        <Ionicons name = "md-document-text" size = {24} color = "white"/>
                    </View>
                    <View style = {[props.row, props.alignCenter, props.itemContent]}>
                        <Text style = {[props.p, props.b, props.leftMargin]}>{props.other3}</Text>
                        <AntDesign name = "right" size = {20} color = "white"/>
                    </View>
                </TouchableOpacity>
            </View>
        </View>
    )

    return (
        <SafeAreaView style = {styles.safeAreaContainer}>
            <View style = {styles.container}>
                <LinearGradient colors = {['rgba(232, 69, 69, 1)', 'rgba(43, 46, 74, 1)']} style = {styles.bg}>
                    <ScrollView>
                        <Header header = {styles.header}/>
                        <Body 
                            body = {styles.body}
                            dashboardCont = {styles.dashboardCont}
                            h2 = {[styles.h2, styles.fontColor]}
                            p = {[styles.p, styles.fontColor]}
                            p1 = {[styles.p1, styles.fontColor]}
                            b = {[styles.b, styles.fontColor]}
                            dashboardTitle = {"Your dashboard"}
                            topSpacer = {styles.topSpacer}
                            topMargin = {styles.topMargin}
                            pfpCont = {styles.pfpCont}
                            pfp = {styles.pfp}
                            row = {styles.row}
                            alignCenter = {styles.alignCenter}
                            pfContent = {styles.pfContent}
                            pfDesc = {styles.pfDesc}
                            user = {"Isaac Wong"}
                            menuTitle = {"Looking for something?"}
                            iconCont = {styles.iconCont}
                            itemContent = {styles.itemContent}
                            item1 = {"Progress log"}
                            item2 = {"Routines & guides"}
                            item3 = {"Leaderboards"}
                            item4 = {"Rewards"}
                            item5 = {"Weight calculator"}
                            other1 = {"Notifications"}
                            other2 = {"Terms of use"}
                            other3 = {"Privacy policy"}
                            link1 = {() => navigation.navigate("log")}
                            link2 = {() => navigation.navigate("guides")}
                            link3 = {() => navigation.navigate("leaderboards")}
                            link4 = {() => navigation.navigate("rewards")}
                            link5 = {() => navigation.navigate("calculator")}
                        />
                    </ScrollView>
                </LinearGradient>
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    safeAreaContainer: {
        flex: 1,
    },
    container: {
        flex: 1,
    },
    bg: {
        flex: 1,
    },
    h1: {
        fontSize: 30,
        fontWeight: "bold",
    },
    h2: {
        fontSize: 20,
        fontWeight: "bold",
    },
    p: {
        fontSize: 16,
    },
    p1: {
        fontSize: 12,
    },
    b: {
        fontWeight: "bold",
    },
    fontColor: {
        color: "white",
    },
    centerText: {
        textAlign: "center",
    },
    topSpacer: {
        marginTop: "10%",
    },
    topMargin: {
        marginTop: "5%",
    },
    leftMargin: {
        marginLeft: "5%",
    },
    rightMargin: {
        marginRight: "5%",
    },
    alignCenter: {
        alignItems: "center",
    },
    row: {
        flexDirection: "row",
    },
    header: {
        flexDirection: "row",
        paddingHorizontal: "10%",
        paddingTop: "15%",
        paddingBottom: "3%",
        alignItems: "center",
    },
    arrow: {
        width: 36,
        height: 36,
        zIndex: 100,
        justifyContent: "center",
        alignItems: "center",
    },
    stage: {
        width: "100%",
        position: "absolute",
        left: "12.5%",
        bottom: 0,
        alignItems: "center",
        opacity: 0,
    },
    stageTitle: {
        paddingHorizontal: 16,
        paddingVertical: 5,
        borderRadius: 1000,
        backgroundColor: "rgba(66, 72, 116, 1)",
        marginBottom: "-2.5%",
        zIndex: 100,
    },
    stageDesc: {
        paddingHorizontal: 16,
        paddingVertical: 8,
        borderRadius: 1000,
        backgroundColor: "rgba(255, 255, 255, 0.4)",
        zIndex: 99,
    },
    body: {
        flex: 1,
        paddingTop: "10%",
        paddingBottom: "15%",
        paddingHorizontal: "10%",
    },
    pfpCont: {
        width: 80,
        height: 80,
        borderRadius: 1000,
        borderWidth: 1,
        borderColor: "white",
        backgroundColor: "rgba(255, 255, 255, 0.2)",
        justifyContent: "center",
        alignItems: "center",
    },
    pfp: {
        width: 50,
        height: 50,
    },
    pfContent: {
        flex: 1,
        justifyContent: "space-between",
    },
    pfDesc: {
        marginLeft: "10%",
    },
    iconCont: {
        width: 55,
        height: 55,
        borderRadius: 1000,
        borderWidth: 1,
        borderColor: "white",
        backgroundColor: "rgba(255, 255, 255, 0.2)",
        justifyContent: "center",
        alignItems: "center",
        marginRight: "10%",
    },
    itemContent: {
        flex: 1,
        justifyContent: "space-between",
    }
})