import { StyleSheet, Text, View, SafeAreaView, TouchableOpacity, Image } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function Start({navigation}) {
    const CTA = (props) => (
        <TouchableOpacity style = {props.button} onPress = {props.action}>
            <Text style = {props.font}>{props.text}</Text>
        </TouchableOpacity>
    )

    return(
        <SafeAreaView style = {styles.safeAreaContainer}>
            <View style = {styles.container}>
                <LinearGradient colors = {['rgba(232, 69, 69, 1)', 'rgba(43, 46, 74, 1)']} style = {styles.bg}>
                    <Image style = {styles.trainer} source = {require("../assets/trainer.png")}></Image>
                    <View style = {styles.message}>
                        <Text style = {[styles.h1, styles.fontColor, styles.title]}>Your best workout buddy ever!</Text>
                        <Text style = {[styles.p, styles.fontColor, styles.desc]}>Tell us more about yourself, and about your goals for strength training! We'll make sure you'll have a fun time doing it!</Text>
                        <CTA 
                            text = {"Get started"}
                            button = {styles.button} 
                            font = {[styles.p, styles.b, styles.fontColor, styles.centerText]} 
                            action = {() => navigation.navigate("q1")}
                        />
                    </View>
                </LinearGradient>
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    safeAreaContainer: {
        flex: 1,
    },
    container: {
        flex: 1,
    },
    bg: {
        flex: 1,
        justifyContent: "flex-end",
    },
    h1: {
        fontSize: 30,
        fontWeight: "bold",
    },
    p: {
        fontSize: 16,
    },
    b: {
        fontWeight: "bold",
    },
    fontColor: {
        color: "white",
    },
    centerText: {
        textAlign: "center",
    },
    trainer: {
        width: "65%",
        height: "65%",
        alignSelf: "center",
        marginBottom: "-20%",
    },
    message: {
        paddingHorizontal: "10%",
        paddingVertical: "10%",
        backgroundColor: "rgba(66, 72, 116, 1)",
    },
    desc: {
        marginTop: "2%",
        marginBottom: "10%",
    },
    button: {
        paddingHorizontal: 16,
        paddingVertical: 8,
        backgroundColor: "rgba(166, 177, 225, 1)",
        borderRadius: 1000,
    },
})