import { StyleSheet, Text, View, SafeAreaView, TouchableOpacity, TextInput } from 'react-native'
import 'react-native-gesture-handler'
import SelectDropdown from 'react-native-select-dropdown'
import { LinearGradient } from 'expo-linear-gradient'
import { useState } from "react"
import { Entypo } from '@expo/vector-icons' 

export default function Start({navigation}) {
    const CTA = (props) => (
        <TouchableOpacity style = {props.button} onPress = {props.action}>
            <Text style = {props.font}>{props.text}</Text>
        </TouchableOpacity>
    )

    const countries = ["Singapore", "Malaysia", "Japan", "Thailand"]
    const [height, onChangeHeight] = useState("")
    const [weight, onChangeWeight] = useState("")
    const [name, onChangeName] = useState("")

    return(
        <SafeAreaView style = {styles.safeAreaContainer}>
            <View style = {styles.container}>
              <LinearGradient colors = {['rgba(232, 69, 69, 1)', 'rgba(43, 46, 74, 1)']} style = {styles.bg}>
                <Text style = {[styles.h1, styles.fontColor]}>Lastly, tell us a bit more about yourself!</Text>
                <View style = {[styles.formContainer, styles.topSpacer]}>
                    <View style = {styles.location}>
                        <Text style = {[styles.h2, styles.fontColor, styles.title]}>Location</Text>
                        <SelectDropdown
                            data = {countries} 
                            onSelect = {(selectedItem, index) => {
                                console.log(selectedItem, index)
                            }}
                            buttonTextAfterSelection={(selectedItem, index) => {
                                // text represented after item is selected
                                // if data array is an array of objects then return selectedItem.property to render after item is selected
                                return selectedItem
                            }}
                            rowTextForSelection={(item, index) => {
                                // text represented for each item in dropdown
                                // if data array is an array of objects then return item.property to represent item in dropdown
                                return item
                            }}
                            buttonStyle = {styles.input}
                            defaultButtonText = {'Select a country'}
                            buttonTextStyle = {[styles.p, styles.fontColor]}
                            renderDropdownIcon = {isOpened => {
                                return <Entypo style = {styles.dropdown} name = "chevron-small-down" size = {20} color = "white"/>
                            }}
                        />
                    </View>
                    <View style = {[styles.stats, styles.topMargin]}>
                        <View style = {[styles.heightCont, styles.rightMargin]}>
                            <Text style = {[styles.h2, styles.fontColor, styles.title]}>Height</Text>
                            <TextInput
                                style = {[styles.input, styles.inputPadding, styles.p, styles.fontColor]}
                                onChangeText = {onChangeHeight}
                                value = {height}
                                placeholder = {"Height (cm)"}
                                placeholderTextColor = {"#fff"}
                                keyboardType = "numeric"
                            />
                        </View>
                        <View style = {[styles.weightCont, styles.leftMargin]}>
                            <Text style = {[styles.h2, styles.fontColor, styles.title]}>Weight</Text>
                            <TextInput
                                style = {[styles.input, styles.inputPadding, styles.p, styles.fontColor]}
                                onChangeText = {onChangeWeight}
                                value = {weight}
                                placeholder = {"Weight (kg)"}
                                placeholderTextColor = {"#fff"}
                                keyboardType = "numeric"
                            />
                        </View>
                    </View>
                    <View style = {[styles.name, styles.topMargin]}>
                        <Text style = {[styles.h2, styles.fontColor, styles.title]}>Name</Text>
                        <TextInput
                            style = {[styles.input, styles.inputPadding, styles.p, styles.fontColor]}
                            onChangeText = {onChangeName}
                            value = {name}
                            placeholder = {"Display name"}
                            placeholderTextColor = {"#fff"}
                        />
                    </View>
                    <CTA
                        button = {[styles.button, styles.topSpacer]}
                        font = {[styles.p, styles.b, styles.centerText, styles.fontColor]}
                        text = {"Let me start already!"}
                        action = {() => navigation.navigate("home")}
                    />
                </View>
              </LinearGradient>
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    safeAreaContainer: {
        flex: 1,
    },
    container: {
        flex: 1,
    },
    bg: {
        flex: 1,
        padding: "10%",
        alignItems: "center",
        justifyContent: "center",
    },
    h1: {
        fontSize: 30,
        fontWeight: "bold",
    },
    h2: {
        fontSize: 20,
        fontWeight: "bold",
    },
    p: {
        fontSize: 16,
    },
    b: {
        fontWeight: "bold",
    },
    fontColor: {
        color: "white",
    },
    centerText: {
        textAlign: "center",
    },
    topSpacer: {
        marginTop: "10%",
    },
    topMargin: {
        marginTop: "5%",
    },
    leftMargin: {
        marginLeft: "5%",
    },
    rightMargin: {
        marginRight: "5%",
    },
    formContainer: {
        width: "90%",
        justifyContent: "flex-start",
    },
    title: {
        marginBottom: "2.5%",
    },
    input: {
        width: "100%",
        height: 40,
        borderRadius: 12,
        backgroundColor: "rgba(255, 255, 255, 0.2)",
    },
    inputPadding: {
        paddingHorizontal: 16,
    },
    dropdown: {
        paddingLeft: 8,
        borderLeftWidth: 1,
        borderColor: "white",
    },
    title: {
        marginBottom: "5%",
    },
    stats: {
        flexDirection: "row",
        alignItems: "center",
    },
    heightCont: {
        flex: 1,
    },
    weightCont: {
        flex: 1,
    },
    button: {
        width: "80%",
        paddingHorizontal: 16,
        paddingVertical: 8,
        backgroundColor: "rgba(166, 177, 225, 0.75)",
        borderRadius: 1000,
        alignSelf: "center",
    }
})