import { StyleSheet, Text, View, SafeAreaView, TouchableOpacity, Image, ScrollView, Dimensions } from 'react-native';
import 'react-native-gesture-handler';
import { Ionicons, MaterialCommunityIcons, MaterialIcons, FontAwesome5, AntDesign } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

const {height, width} = Dimensions.get('window');

export default function Leaderboards({navigation}) {
    const Back = (props) => (
        <TouchableOpacity style = {props.arrow} onPress = {props.action}>
            <Ionicons name = "ios-arrow-back" size = {30} color = "white"/>
        </TouchableOpacity>
    )

    const Stage = (props) => (
        <View style = {props.header}>
            <Text style = {props.titleFont}>{props.title}</Text>
            <Text style = {props.descFont}>{props.desc}</Text>
        </View>
    )

    const Header = (props) => (
        <View style = {props.header}>
            <Back arrow = {styles.arrow} action = {() => navigation.goBack()}/>
            <Stage 
                header = {styles.stage}
                titleFont = {[styles.h2, styles.fontColor, styles.stageTitle]}
                title = {"Stage 1"}
                descFont = {[styles.p, styles.fontColor, styles.stageDesc]}
                desc = {"1,000 to next stage"}
            />
        </View>
    )
    
    const Body = (props) => (
        <View style = {props.body}>
            <Text style = {[props.h2, props.fontColor]}>{props.title}</Text>
            <View style = {props.leaderboard}>
                <View>
                    <View style = {props.row}>
                        <FontAwesome5 name = "crown" size = {24} color = "gold"/>
                        <Text style = {[props.h2, props.rank, props.leftMargin]}>1</Text>
                        <Text style = {[props.h2, props.name]}>Joshua Ler</Text>
                    </View>
                    <View style = {props.hr}/>
                    <View style = {props.row}>
                        <FontAwesome5 style = {props.additionalSpace} name = "crown" size = {20} color = "silver"/>
                        <Text style = {[props.h2, props.rank, props.leftMargin]}>2</Text>
                        <Text style = {[props.h2, props.name]}>Eric Chen</Text>
                    </View>
                    <View style = {props.hr}/>
                    <View style = {props.row}>
                        <FontAwesome5 style = {props.additionalSpace} name = "crown" size = {20} color = "rgba(205, 127, 50, 1)"/>
                        <Text style = {[props.h2, props.rank, props.leftMargin]}>3</Text>
                        <Text style = {[props.h2, props.name]}>Darren Tan</Text>
                    </View>
                    <View style = {props.hr}/>
                </View>
                <Text style = {[props.h2, props.alignSelf]}>.</Text>
                <Text style = {[props.h2, props.alignSelf]}>.</Text>
                <Text style = {[props.h2, props.alignSelf]}>.</Text>
                <Text style = {[props.h2, props.alignSelf]}>.</Text>
                <Text style = {[props.h2, props.alignSelf]}>.</Text>
                <View>
                    <View style = {props.hr}/>
                    <View style = {props.row}>
                        <FontAwesome5 style = {props.additionalSpace} name = "crown" size = {20} color = "black"/>
                        <Text style = {[props.h2, props.rank, props.leftMargin]}>10</Text>
                        <Text style = {[props.h2, props.name]}>Isaac Wong</Text>
                    </View>
                </View>
            </View>
        </View>
    )

    return (
        <SafeAreaView style = {styles.safeAreaContainer}>
            <View style = {styles.container}>
                <LinearGradient colors = {['rgba(232, 69, 69, 1)', 'rgba(43, 46, 74, 1)']} style = {styles.bg}>
                    <Header header = {styles.header}/>
                    <Body 
                        body = {styles.body}
                        leaderboard = {styles.leaderboard}
                        h2 = {styles.h2}
                        fontColor = {styles.fontColor}
                        title = {"Weekly leaderboards"}
                        row = {styles.row}
                        name = {styles.leftMargin}
                        hr = {styles.hr}
                        additionalSpace = {styles.additionalSpace}
                        leftMargin = {styles.leftMargin}
                        alignSelf = {styles.alignCenter}
                    />
                </LinearGradient>
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    safeAreaContainer: {
        flex: 1,
    },
    container: {
        flex: 1,
    },
    bg: {
        flex: 1,
    },
    h1: {
        fontSize: 30,
        fontWeight: "bold",
    },
    h2: {
        fontSize: 20,
        fontWeight: "bold",
    },
    p: {
        fontSize: 16,
    },
    b: {
        fontWeight: "bold",
    },
    fontColor: {
        color: "white",
    },
    centerText: {
        textAlign: "center",
    },
    alignCenter: {
        alignSelf: "center",
    },
    topSpacer: {
        marginTop: "10%",
    },
    topMargin: {
        marginTop: "5%",
    },
    leftMargin: {
        marginLeft: "5%",
    },
    rightMargin: {
        marginRight: "5%",
    },
    row: {
        flexDirection: "row",
        alignItems: "center",
    },
    hr: {
        width: "100%",
        height: 2,
        borderRadius: 1000,
        backgroundColor: "#d3d3d3",
        marginVertical: "10%",
    },
    header: {
        flexDirection: "row",
        paddingHorizontal: "10%",
        paddingTop: "15%",
        paddingBottom: "3%",
        alignItems: "center",
    },
    arrow: {
        width: 36,
        height: 36,
        zIndex: 100,
        justifyContent: "center",
        alignItems: "center",
    },
    stage: {
        width: "100%",
        position: "absolute",
        left: "12.5%",
        bottom: 0,
        alignItems: "center",
        opacity: 0,
    },
    stageTitle: {
        paddingHorizontal: 16,
        paddingVertical: 5,
        borderRadius: 1000,
        backgroundColor: "rgba(66, 72, 116, 1)",
        marginBottom: "-2.5%",
        zIndex: 100,
    },
    stageDesc: {
        paddingHorizontal: 16,
        paddingVertical: 8,
        borderRadius: 1000,
        backgroundColor: "rgba(255, 255, 255, 0.4)",
        zIndex: 99,
    },
    body: {
        flex: 1,
        paddingTop: "10%",
        paddingBottom: "15%",
        paddingHorizontal: "10%",
    },
    leaderboard: {
        flex: 1,
        borderRadius: 12,
        backgroundColor: "white",
        marginTop: "10%",
        padding: "10%",
    },
    additionalSpace: {
        marginRight: 4,
    }
})