import { StyleSheet, Text, View, SafeAreaView, TouchableOpacity, Image, ScrollView } from 'react-native'
import SwipeUpDown from 'react-native-swipe-up-down'
import { LinearGradient } from 'expo-linear-gradient'
import { Ionicons } from '@expo/vector-icons'
import { Camera, CameraType } from 'expo-camera'
import { useState, useRef, useEffect } from "react"

export default function Cam({navigation}) {
    const Back = (props) => (
        <TouchableOpacity style = {props.arrow} onPress = {props.action}>
            <Ionicons name = "ios-arrow-back" size = {30} color = "white"/>
        </TouchableOpacity>
    )

    const Stage = (props) => (
        <View style = {props.header}>
            <Text style = {props.titleFont}>{props.title}</Text>
            <Text style = {props.descFont}>{props.desc}</Text>
        </View>
    )

    const Header = (props) => (
        <View style = {props.header}>
            <Back arrow = {styles.arrow} action = {() => navigation.goBack()}/>
            <Stage 
                header = {styles.stage}
                titleFont = {[styles.h2, styles.fontColor, styles.stageTitle]}
                title = {"Stage 1"}
                descFont = {[styles.p, styles.fontColor, styles.stageDesc]}
                desc = {"1,000 to next stage"}
            />
        </View>
    )
    
    const Body = (props) => (
        <View style = {props.body}>
            <View style = {{overflow: "hidden"}}>
                <View style = {props.dotted}/>
            </View>
        </View>
    )

    const Draggable = (props) => (
        <SwipeUpDown
            itemMini = {
                <View style = {props.mini}>
                    <View style = {props.indicator}/>
                    <View style = {[props.row, props.alignCenter, props.spaceBetween, props.textCont]}>
                        <View >
                            <Text style = {props.h2}>Bench press</Text>
                            <Text style = {props.p}>Task 1</Text>
                        </View>
                        <Text style = {props.h2}>(0/5)</Text>
                    </View>
                </View>
            }
            itemFull = {
                <View style = {props.full}>
                    <View style = {props.indicator}/>
                    <View style = {props.fullCont}>
                        <ScrollView>
                            <View style = {props.row}>
                                <Text style = {props.h2}>Performing the lift</Text>
                            </View>
                            <View style = {[props.row, props.topSpacer, props.justifyCenter]}>
                                <Image style = {props.img} source = {require("../assets/bench2.png")}></Image>
                            </View>
                            <View style = {[props.row, props.topSpacer, props.alignCenter]}>
                                <View style = {[props.num, props.alignCenter, props.justifyCenter]}>
                                    <Text style = {[props.p, props.b]}>1</Text>
                                </View>
                                <Text style = {[props.p, props.instructions]}>Position your body so that your chin is directly under the bar.</Text>
                            </View>
                            <View style = {[props.row, props.topMargin, props.alignCenter]}>
                                <View style = {[props.num, props.alignCenter, props.justifyCenter]}>
                                    <Text style = {[props.p, props.b]}>2</Text>
                                </View>
                                <Text style = {[props.p, props.instructions]}>Press your shoulder blades into the bench, and plant your feet firmly on the ground.</Text>
                            </View>
                            <View style = {[props.row, props.topMargin, props.alignCenter]}>
                                <View style = {[props.num, props.alignCenter, props.justifyCenter]}>
                                    <Text style = {[props.p, props.b]}>3</Text>
                                </View>
                                <Text style = {[props.p, props.instructions]}>Grip around the bar at about shoulder width apart.</Text>
                            </View>
                            <View style = {[props.row, props.topMargin, props.alignCenter]}>
                                <View style = {[props.num, props.alignCenter, props.justifyCenter]}>
                                    <Text style = {[props.p, props.b]}>4</Text>
                                </View>
                                <Text style = {[props.p, props.instructions]}>Rest the bar within the cradle of your hands.</Text>
                            </View>
                            <View style = {[props.row, props.topMargin, props.alignCenter]}>
                                <View style = {[props.num, props.alignCenter, props.justifyCenter]}>
                                    <Text style = {[props.p, props.b]}>5</Text>
                                </View>
                                <Text style = {[props.p, props.instructions]}>Unrack the bar and bring it down to your chest. The bar path should be moving vertically.</Text>
                            </View>
                            <View style = {[props.row, props.topMargin, props.alignCenter]}>
                                <View style = {[props.num, props.alignCenter, props.justifyCenter]}>
                                    <Text style = {[props.p, props.b]}>6</Text>
                                </View>
                                <Text style = {[props.p, props.instructions]}>Press the bar back upwards and fully extend your arms. This is a single repetition.</Text>
                            </View>
                        </ScrollView>
                    </View>
                </View>
            }
            onShowMini = {() => console.log('mini')}
            onShowFull = {() => console.log('full')}
            extraMarginTop = {24}
            disableSwipeIcon = {true}
            animation = {"easeInEaseOut"}
            style = {props.draggable}
            swipeHeight = {110}
        />
    )

    const [type, setType] = useState(CameraType.front)
    const [permission, setPermission] = useState(null)
    const [screen, setScreen] = useState(null)
    const cameraRef = useRef(null)

    useEffect(() => {
        (async() => {
            const camStatus = await Camera.requestCameraPermissionsAsync()
            setPermission(camStatus.status === "granted")
        })()
    }, [])

    return(
        <SafeAreaView style = {styles.safeAreaContainer}>
            <View style = {styles.container}>
                <Camera style = {[styles.camera, styles.justifyCenter]} type = {type}>
                    <Header header = {styles.header}/>
                    <Body 
                        body = {styles.body}
                        dotted = {styles.dotted}
                    />
                    <Draggable 
                        draggable = {styles.drag} 
                        textCont = {styles.text}
                        fullCont = {styles.fullCont}
                        spaceBetween = {styles.spaceBetween}
                        mini = {styles.mini} 
                        full = {styles.full}
                        indicator = {styles.indicator}
                        h2 = {[styles.h2, styles.fontColor]}
                        p = {[styles.p, styles.fontColor]}
                        p1 = {[styles.p1, styles.fontColor]}
                        b = {styles.b}
                        row = {styles.row}
                        alignCenter = {styles.alignCenter}
                        justifyCenter = {styles.justifyCenter}
                        img = {styles.img}
                        topMargin = {styles.topMargin}
                        topSpacer = {styles.topSpacer}
                        num = {styles.num}
                        instructions = {styles.instructions}
                    />
                </Camera>
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    safeAreaContainer: {
        flex: 1,
    },
    container: {
        flex: 1,
    },
    bg: {
        flex: 1,
    },
    h1: {
        fontSize: 30,
        fontWeight: "bold",
    },
    h2: {
        fontSize: 20,
        fontWeight: "bold",
    },
    p: {
        fontSize: 16,
    },
    p1: {
        fontSize: 12,
    },
    b: {
        fontWeight: "bold",
    },
    fontColor: {
        color: "white",
    },
    centerText: {
        textAlign: "center",
    },
    topSpacer: {
        marginTop: "10%",
    },
    topMargin: {
        marginTop: "5%",
    },
    leftMargin: {
        marginLeft: "5%",
    },
    rightMargin: {
        marginRight: "5%",
    },
    leftSpacer: {
        marginLeft: "15%",
    },
    alignCenter: {
        alignItems: "center",
    },
    alignEnd: {
        alignItems: "flex-end",
    },
    justifyCenter: {
        justifyContent: "center",
    },
    justifyEnd: {
        justifyContent: "flex-end",
    },
    row: {
        flexDirection: "row",
    },
    flex: {
        flex: 1,
    },
    spaceBetween: {
        justifyContent: "space-between",
    },
    header: {
        flexDirection: "row",
        paddingHorizontal: "10%",
        paddingTop: "15%",
        paddingBottom: "3%",
        alignItems: "center",
    },
    arrow: {
        width: 36,
        height: 36,
        zIndex: 1000,
        justifyContent: "center",
        alignItems: "center",
    },
    stage: {
        width: "100%",
        position: "absolute",
        left: "12.5%",
        bottom: 0,
        alignItems: "center",
        opacity: 0,
    },
    stageTitle: {
        paddingHorizontal: 16,
        paddingVertical: 5,
        borderRadius: 1000,
        backgroundColor: "rgba(66, 72, 116, 1)",
        marginBottom: "-2.5%",
        zIndex: 100,
    },
    stageDesc: {
        paddingHorizontal: 16,
        paddingVertical: 8,
        borderRadius: 1000,
        backgroundColor: "rgba(255, 255, 255, 0.4)",
        zIndex: 99,
    },
    body: {
        flex: 1,
        paddingTop: "10%",
        paddingBottom: "15%",
        paddingHorizontal: "10%",
        justifyContent: "center",
    },
    drag: {
        paddingHorizontal: "10%",
        backgroundColor: "rgba(66, 72, 116, 1)",
    },
    indicator: {
        width: "50%",
        height: 4,
        backgroundColor: "rgba(244, 238, 255, 1)",
        borderRadius: 1000,
        alignSelf: "center",
        marginTop: 8,
    },
    text: {
        marginTop: "8%",
    },
    fullCont: {
        marginTop: "8%",
    },
    camera: {
        flex: 1,
        backgroundColor: "black",
    },
    dotted: {
        width: 1,
        height: "80%",
        borderWidth: 1,
        borderStyle: "dashed",
        borderColor: "white",
        marginLeft: "70%",
    },
    img: {
        width: "88%",
        height: "88%",
        aspectRatio: 2084/1473,
    },
    num: {
        width: 30,
        height: 30,
        borderRadius: 1000,
        backgroundColor: "rgba(166, 177, 225, 0.6)",
    },
    instructions: {
        paddingHorizontal: "10%",
    }
})