import { StyleSheet, Text, View, SafeAreaView, TouchableOpacity, Image, ScrollView } from 'react-native'
import 'react-native-gesture-handler'
import { Ionicons, FontAwesome5, AntDesign } from '@expo/vector-icons'
import { Collapse, CollapseHeader, CollapseBody } from "accordion-collapse-react-native"
import { LinearGradient } from 'expo-linear-gradient'

export default function Rewards({navigation}) {
    const Back = (props) => (
        <TouchableOpacity style = {props.arrow} onPress = {props.action}>
            <Ionicons name = "ios-arrow-back" size = {30} color = "white"/>
        </TouchableOpacity>
    )

    const Stage = (props) => (
        <View style = {props.header}>
            <Text style = {props.titleFont}>{props.title}</Text>
            <Text style = {props.descFont}>{props.desc}</Text>
        </View>
    )

    const Header = (props) => (
        <View style = {props.header}>
            <Back arrow = {styles.arrow} action = {() => navigation.goBack()}/>
            <Stage 
                header = {styles.stage}
                titleFont = {[styles.h2, styles.fontColor, styles.stageTitle]}
                title = {"Stage 1"}
                descFont = {[styles.p, styles.fontColor, styles.stageDesc]}
                desc = {"1,000 to next stage"}
            />
        </View>
    )

    const Body = (props) => (
        <View style = {props.body}>
            <View>
                <Text style = {props.h2}>Your rewards balance</Text>
                <View style = {[props.row, props.justifyContent, props.topMargin]}>
                    <View style = {props.pfpCont}>
                        <Image style = {[props.pfp, {aspectRatio: 234/283}]} source = {require("../assets/pfp.png")}/>
                    </View>
                    <View style = {props.pointsCont}>
                        <View>
                            <Text style = {[props.p, props.b]}>Isaac Wong</Text>
                            <Text style = {props.p1}>Bronze tier</Text>
                        </View>
                        <View style = {props.alignEnd}>
                            <View style = {[props.row, props.alignCenter]}>
                                <FontAwesome5 style = {props.tier} name = "crown" size = {10} color = "gold"/>
                                <Text style = {[props.p, props.b]}>To next tier</Text>
                            </View>
                            <Text style = {props.p1}>1000 points</Text>
                        </View>
                    </View>
                </View>
            </View>
            <View style = {props.topSpacer}>
                <Collapse isExpanded = {false}>
                    <CollapseHeader>
                        <View style = {[props.row, props.spaceBetween, props.alignCenter]}>
                            <Text style = {props.h2}>Bronze rewards</Text>
                            <AntDesign name = "down" size = {16} color = "white"/>
                        </View>
                    </CollapseHeader>
                    <CollapseBody style = {styles.topSpacer}>
                        <View style = {[props.row, props.spaceBetween, props.alignCenter]}>
                            <View>
                                <Text style = {[props.p, props.b]}>$2 Fairprice voucher</Text>
                                <Text style = {props.p1}>500 points</Text>
                            </View>
                            <TouchableOpacity>
                                <Text style = {[props.p1, props.redeem]}>Redeem</Text>
                            </TouchableOpacity>
                        </View>
                        <View style = {[props.row, props.topMargin, props.spaceBetween, props.alignCenter]}>
                            <View>
                                <Text style = {[props.p, props.b]}>$2 Grab voucher</Text>
                                <Text style = {props.p1}>500 points</Text>
                            </View>
                            <TouchableOpacity>
                                <Text style = {[props.p1, props.redeem]}>Redeem</Text>
                            </TouchableOpacity>
                        </View>
                    </CollapseBody>
                </Collapse>
                <Collapse isExpanded = {false} style = {props.topSpacer}>
                    <CollapseHeader>
                        <View style = {[props.row, props.spaceBetween, props.alignCenter]}>
                            <Text style = {props.h2}>Silver rewards</Text>
                            <AntDesign name = "down" size = {16} color = "white"/>
                        </View>
                    </CollapseHeader>
                    <CollapseBody style = {styles.topSpacer}>
                        <View style = {[props.row, props.spaceBetween, props.alignCenter]}>
                            <View>
                                <Text style = {[props.p, props.b]}>$5 Fairprice voucher</Text>
                                <Text style = {props.p1}>1000 points</Text>
                            </View>
                            <TouchableOpacity>
                                <Text style = {[props.p1, props.redeem]}>Redeem</Text>
                            </TouchableOpacity>
                        </View>
                        <View style = {[props.row, props.topMargin, props.spaceBetween, props.alignCenter]}>
                            <View>
                                <Text style = {[props.p, props.b]}>$5 Grab voucher</Text>
                                <Text style = {props.p1}>1000 points</Text>
                            </View>
                            <TouchableOpacity>
                                <Text style = {[props.p1, props.redeem]}>Redeem</Text>
                            </TouchableOpacity>
                        </View>
                    </CollapseBody>
                </Collapse>
                <Collapse isExpanded = {false} style = {props.topSpacer}>
                    <CollapseHeader>
                        <View style = {[props.row, props.spaceBetween, props.alignCenter]}>
                            <Text style = {props.h2}>Gold rewards</Text>
                            <AntDesign name = "down" size = {16} color = "white"/>
                        </View>
                    </CollapseHeader>
                    <CollapseBody style = {styles.topSpacer}>
                        <View style = {[props.row, props.spaceBetween, props.alignCenter]}>
                            <View>
                                <Text style = {[props.p, props.b]}>$20 Fairprice voucher</Text>
                                <Text style = {props.p1}>20,000 points</Text>
                            </View>
                            <TouchableOpacity>
                                <Text style = {[props.p1, props.redeem]}>Redeem</Text>
                            </TouchableOpacity>
                        </View>
                        <View style = {[props.row, props.topMargin, props.spaceBetween, props.alignCenter]}>
                            <View>
                                <Text style = {[props.p, props.b]}>$20 Grab voucher</Text>
                                <Text style = {props.p1}>20,000 points</Text>
                            </View>
                            <TouchableOpacity>
                                <Text style = {[props.p1, props.redeem]}>Redeem</Text>
                            </TouchableOpacity>
                        </View>
                    </CollapseBody>
                </Collapse>
                <Collapse isExpanded = {false} style = {props.topSpacer}>
                    <CollapseHeader>
                        <View style = {[props.row, props.spaceBetween, props.alignCenter]}>
                            <Text style = {props.h2}>Platinum rewards</Text>
                            <AntDesign name = "down" size = {16} color = "white"/>
                        </View>
                    </CollapseHeader>
                    <CollapseBody style = {styles.topSpacer}>
                        <View style = {[props.row, props.spaceBetween, props.alignCenter]}>
                            <View>
                                <Text style = {[props.p, props.b]}>$50 Fairprice voucher</Text>
                                <Text style = {props.p1}>30,000 points</Text>
                            </View>
                            <TouchableOpacity>
                                <Text style = {[props.p1, props.redeem]}>Redeem</Text>
                            </TouchableOpacity>
                        </View>
                        <View style = {[props.row, props.topMargin, props.spaceBetween, props.alignCenter]}>
                            <View>
                                <Text style = {[props.p, props.b]}>$50 Grab voucher</Text>
                                <Text style = {props.p1}>30,000 points</Text>
                            </View>
                            <TouchableOpacity>
                                <Text style = {[props.p1, props.redeem]}>Redeem</Text>
                            </TouchableOpacity>
                        </View>
                    </CollapseBody>
                </Collapse>
            </View>
        </View>
    )

    return (
        <SafeAreaView style = {styles.safeAreaContainer}>
            <View style = {styles.container}>
                <LinearGradient colors = {['rgba(232, 69, 69, 1)', 'rgba(43, 46, 74, 1)']} style = {styles.bg}>
                    <ScrollView>
                        <Header header = {styles.header}/>
                        <Body 
                            body = {styles.body}
                            row = {styles.row}
                            h2 = {[styles.h2, styles.fontColor]}
                            p = {[styles.p, styles.fontColor]}
                            p1 = {[styles.p1, styles.fontColor]}
                            b = {styles.b}
                            topMargin = {styles.topMargin}
                            topSpacer = {styles.topSpacer}
                            alignCenter = {styles.alignCenter}
                            alignEnd = {styles.alignEnd}
                            spaceBetween = {styles.spaceBetween}
                            pfpCont = {styles.pfpCont}
                            pfp = {styles.pfp}
                            pointsCont = {[styles.row, styles.pointsCont, styles.alignCenter, styles.spaceBetween]}
                            tier = {styles.tier}
                            redeem = {styles.redeem}
                            collapse = {styles.collapse}
                        />
                    </ScrollView>
                </LinearGradient>
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    safeAreaContainer: {
        flex: 1,
    },
    container: {
        flex: 1,
    },
    bg: {
        flex: 1,
    },
    h1: {
        fontSize: 30,
        fontWeight: "bold",
    },
    h2: {
        fontSize: 20,
        fontWeight: "bold",
    },
    p: {
        fontSize: 16,
    },
    p1: {
        fontSize: 12,
    },
    b: {
        fontWeight: "bold",
    },
    fontColor: {
        color: "white",
    },
    centerText: {
        textAlign: "center",
    },
    topSpacer: {
        marginTop: "10%",
    },
    topMargin: {
        marginTop: "5%",
    },
    leftMargin: {
        marginLeft: "5%",
    },
    rightMargin: {
        marginRight: "5%",
    },
    alignCenter: {
        alignItems: "center",
    },
    alignEnd: {
        alignItems: "flex-end",
    },
    justifyEnd: {
        justifyContent: "flex-end",
    },
    row: {
        flexDirection: "row",
    },
    flex: {
        flex: 1,
    },
    spaceBetween: {
        justifyContent: "space-between",
    },
    header: {
        flexDirection: "row",
        paddingHorizontal: "10%",
        paddingTop: "15%",
        paddingBottom: "3%",
        alignItems: "center",
    },
    arrow: {
        width: 36,
        height: 36,
        zIndex: 100,
        justifyContent: "center",
        alignItems: "center",
    },
    stage: {
        width: "100%",
        position: "absolute",
        left: "12.5%",
        bottom: 0,
        alignItems: "center",
        opacity: 0,
    },
    stageTitle: {
        paddingHorizontal: 16,
        paddingVertical: 5,
        borderRadius: 1000,
        backgroundColor: "rgba(66, 72, 116, 1)",
        marginBottom: "-2.5%",
        zIndex: 100,
    },
    stageDesc: {
        paddingHorizontal: 16,
        paddingVertical: 8,
        borderRadius: 1000,
        backgroundColor: "rgba(255, 255, 255, 0.4)",
        zIndex: 99,
    },
    body: {
        flex: 1,
        paddingTop: "10%",
        paddingBottom: "15%",
        paddingHorizontal: "10%",
    },
    pfpCont: {
        width: 80,
        height: 80,
        borderRadius: 1000,
        borderWidth: 1,
        borderColor: "white",
        backgroundColor: "rgba(255, 255, 255, 0.2)",
        justifyContent: "center",
        alignItems: "center",
    },
    pfp: {
        width: 50,
        height: 50,
    },
    pointsCont: {
        flex: 1,
        marginLeft: "10%",
    },
    tier: {
        marginRight: 5,
    },
    redeem: {
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: 1000,
        backgroundColor: "rgba(166, 177, 225, 0.75)",
    },
})