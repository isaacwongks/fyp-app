import { StyleSheet, Text, View, SafeAreaView, TouchableOpacity, Image, ScrollView } from 'react-native';
import 'react-native-gesture-handler';
import { Ionicons, AntDesign } from '@expo/vector-icons';
import { useState } from "react";
import { LinearGradient } from 'expo-linear-gradient'
import { SearchBar } from '@rneui/themed';
import { Cell, Section, TableView } from 'react-native-tableview-simple';

export default function Guides({navigation}) {
    const Back = (props) => (
        <TouchableOpacity style = {props.arrow} onPress = {props.action}>
            <Ionicons name = "ios-arrow-back" size = {30} color = "white"/>
        </TouchableOpacity>
    )

    const Stage = (props) => (
        <View style = {props.header}>
            <Text style = {props.titleFont}>{props.title}</Text>
            <Text style = {props.descFont}>{props.desc}</Text>
        </View>
    )

    const Header = (props) => (
        <View style = {props.header}>
            <Back arrow = {styles.arrow} action = {() => navigation.goBack()}/>
            <Stage 
                header = {styles.stage}
                titleFont = {[styles.h2, styles.fontColor, styles.stageTitle]}
                title = {"Stage 1"}
                descFont = {[styles.p, styles.fontColor, styles.stageDesc]}
                desc = {"1,000 to next stage"}
            />
        </View>
    )

    const Content = {
        content: [
            {
                title: "Powerbuilding 1.0",
                desc: "Full body workout",
                duration: "5 days",
            },
            {
                title: "Powerbuilding 2.0",
                desc: "Upper/lower body split",
                duration: "4 days",
            },
            {
                title: "Powerbuilding 3.0",
                desc: "Full body workout",
                duration: "5 days",
            }
        ]
    }

    const ItemCell = (props) => (
        <Cell
            backgroundColor = "transparent"
            highlightUnderlayColor = "#ccc"
            cellContentView = {
                <TouchableOpacity style = {props.itemCont}>
                    <View style = {[props.row, props.spaceBetween, props.alignEnd]}>
                        <View>
                            <Text style = {[props.p, props.b, props.fontColor]}>{props.itemName}</Text>
                            <Text style = {[props.p1, props.fontColor]}>{props.itemDesc}</Text>
                        </View>
                        <Text style = {[props.p, props.fontColor]}>{props.duration}</Text>
                    </View>
                    <TouchableOpacity style = {props.fav}>
                        <AntDesign name = "staro" size = {20} color = "white"/>
                    </TouchableOpacity>
                </TouchableOpacity>
            }
        />
    )
        
    const [search, setSearch] = useState("")
    const updateSearch = (search) => {
        setSearch(search)
    }

    const Body = (props) => (
        <View style = {props.body}>
            <ScrollView>
                <View>
                    <Text style = {props.h2}>{props.pageTitle}</Text>
                    <SearchBar
                        platform = "ios"
                        containerStyle = {[props.searchCont, props.topMargin]}
                        inputContainerStyle = {props.searchInput}
                        inputStyle = {[props.p, props.fontColor]}
                        loadingProps = {{}}
                        onChangeText = {updateSearch}
                        onClearText = {() => console.log("cleared")}
                        placeholder = "Looking for something?"
                        placeholderTextColor = "white"
                        value = {search}
                        searchIcon = {props.searchIcon}
                        showCancel = {false}
                        round = {true}
                    />
                </View>
                <View style = {props.topSpacer}>
                    <Text style = {props.h2}>{props.sectionTitle}</Text>
                    <TableView>
                        {Content.content.map((item) => (
                            <ItemCell
                                itemCont = {[styles.itemCont, styles.topMargin, styles.justifyEnd]}
                                row = {[styles.row, styles.spaceBetween, styles.alignEnd]}
                                p = {styles.p}
                                p1 = {styles.p1}
                                b = {styles.b}
                                fontColor = {styles.fontColor}
                                itemName = {item.title}
                                itemDesc = {item.desc}
                                duration = {item.duration}
                                fav = {styles.fav}
                            />
                        ))}
                    </TableView>
                </View>
            </ScrollView>
        </View>
    )

    return (
        <SafeAreaView style = {styles.safeAreaContainer}>
            <View style = {styles.container}>
                <LinearGradient colors = {['rgba(232, 69, 69, 1)', 'rgba(43, 46, 74, 1)']} style = {styles.bg}>
                    <Header header = {styles.header}/>
                    <Body
                        body = {styles.body}
                        h2 = {[styles.h2, styles.fontColor]}
                        p = {[styles.p, styles.fontColor]}
                        b = {styles.b}
                        row = {styles.row}
                        pageTitle = {"Routines & guides"}
                        searchCont = {styles.searchCont}
                        searchInput = {styles.searchInput}
                        searchIcon = {styles.searchIcon}
                        topMargin = {styles.topMargin}
                        topSpacer = {styles.topSpacer}
                        sectionTitle = {"Recommended workout routines"}
                    />
                </LinearGradient>
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    safeAreaContainer: {
        flex: 1,
    },
    container: {
        flex: 1,
    },
    bg: {
        flex: 1,
    },
    h1: {
        fontSize: 30,
        fontWeight: "bold",
    },
    h2: {
        fontSize: 20,
        fontWeight: "bold",
    },
    p: {
        fontSize: 16,
    },
    p1: {
        fontSize: 12,
    },
    b: {
        fontWeight: "bold",
    },
    fontColor: {
        color: "white",
    },
    centerText: {
        textAlign: "center",
    },
    topSpacer: {
        marginTop: "10%",
    },
    topMargin: {
        marginTop: "5%",
    },
    leftMargin: {
        marginLeft: "5%",
    },
    rightMargin: {
        marginRight: "5%",
    },
    alignCenter: {
        alignItems: "center",
    },
    alignEnd: {
        alignItems: "flex-end",
    },
    justifyEnd: {
        justifyContent: "flex-end",
    },
    row: {
        flexDirection: "row",
    },
    flex: {
        flex: 1,
    },
    spaceBetween: {
        justifyContent: "space-between",
    },
    header: {
        flexDirection: "row",
        paddingHorizontal: "10%",
        paddingTop: "15%",
        paddingBottom: "3%",
        alignItems: "center",
    },
    arrow: {
        width: 36,
        height: 36,
        zIndex: 100,
        justifyContent: "center",
        alignItems: "center",
    },
    stage: {
        width: "100%",
        position: "absolute",
        left: "12.5%",
        bottom: 0,
        alignItems: "center",
        opacity: 0,
    },
    stageTitle: {
        paddingHorizontal: 16,
        paddingVertical: 5,
        borderRadius: 1000,
        backgroundColor: "rgba(66, 72, 116, 1)",
        marginBottom: "-2.5%",
        zIndex: 100,
    },
    stageDesc: {
        paddingHorizontal: 16,
        paddingVertical: 8,
        borderRadius: 1000,
        backgroundColor: "rgba(255, 255, 255, 0.4)",
        zIndex: 99,
    },
    body: {
        flex: 1,
        paddingTop: "10%",
        paddingBottom: "15%",
        paddingHorizontal: "10%",
    },
    searchCont: {
        height: 40,
        padding: 0,
        margin: 0,
        backgroundColor: "transparent",
        borderRadius: 12,
    },
    searchInput: {
        borderRadius: 12,
        backgroundColor: "rgba(255, 255, 255, 0.2)",
    },
    searchIcon: {
        color: "white",
    },
    itemCont: {
        flex: 1,
        height: 140,
        backgroundColor: "rgba(66, 72, 116, 1)",
        borderRadius: 12,
        padding: "10%",
    },
    fav: {
        position: "absolute",
        top: "25%",
        right: "10%",
    }
})