import { NavigationContainer } from '@react-navigation/native'
import { createStackNavigator } from '@react-navigation/stack'

import Start from "./views/start"
import Q1 from "./views/q1"
import Q2 from "./views/q2"
import Form from "./views/form"
import Home from "./views/home"
import Menu from "./views/menu"
import Log from "./views/log"
import Guides from "./views/guides"
import Rewards from "./views/rewards"
import Calculator from "./views/calc"
import Leaderboards from "./views/leaderboards"
import Cam from "./views/cam"

const Stack = createStackNavigator()

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name = "start" component = {Start} options = {{headerShown: false}}></Stack.Screen>
        <Stack.Screen name = "q1" component = {Q1} options = {{headerShown: false}}></Stack.Screen>
        <Stack.Screen name = "q2" component = {Q2} options = {{headerShown: false}}></Stack.Screen>
        <Stack.Screen name = "form" component = {Form} options = {{headerShown: false}}></Stack.Screen>
        <Stack.Screen name = "home" component = {Home} options = {{headerShown: false}}></Stack.Screen>
        <Stack.Screen name = "menu" component = {Menu} options = {{headerShown: false}}></Stack.Screen>
        <Stack.Screen name = "log" component = {Log} options = {{headerShown: false}}></Stack.Screen>
        <Stack.Screen name = "leaderboards" component = {Leaderboards} options = {{headerShown: false}}></Stack.Screen>
        <Stack.Screen name = "guides" component = {Guides} options = {{headerShown: false}}></Stack.Screen>
        <Stack.Screen name = "rewards" component = {Rewards} options = {{headerShown: false}}></Stack.Screen>
        <Stack.Screen name = "calculator" component = {Calculator} options = {{headerShown: false}}></Stack.Screen>
        <Stack.Screen name = "cam" component = {Cam} options = {{headerShown: false}}></Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
  )
}